<!--div class="row">
    <div class="col-md-12 alert-warning alert-dismissable">        
        <h4 style="color:navy"><i class="fa fa-home"></i> Welcome</h4>          
    </div>
    <div class="col-md-12 alert-warning alert-dismissable">        
        <img src="<?php echo base_url(); ?>img/bg.png" width="100%"> 
    </div>
</div-->
<div class="page-head">
    <div class="page-title">
            <h1>Home <small>Welcome</small></h1>
    </div>
</div>
<div class="row">
    <div class="col-md-12">        
        <img src="<?php echo base_url(); ?>img/bg.png" width="100%"> 
    </div>
</div>
