<div class="row">
    <div class="col-md-12 alert-warning alert-dismissable">        
        <h5 style="color:navy">
            <a href="<?php echo base_url(); ?>"> <i class="fa fa-home"></i> Home </a> 
            <i class="fa fa-angle-right"></i> Gudang Bobbin
            <i class="fa fa-angle-right"></i> 
            <a href="<?php echo base_url('index.php/GudangBobbin/add_penerimaan_bobbin'); ?>"> Create Penerimaan Bobbin </a> 
        </h5>          
    </div>
</div>
<div class="row">&nbsp;</div>
<div class="row">                            
    <div class="col-md-12"> 
        <?php
            if( ($group_id==1)||($hak_akses['add_spb']==1) ){
        ?>
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
                    <span id="message">&nbsp;</span>
                </div>
            </div>
        </div>
        <form class="eventInsForm" method="post" target="_self" name="formku" 
              id="formku" action="<?php echo base_url('index.php/GudangBobbin/save_penerimaan_bobbin'); ?>">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-4">
                            No. Penerimaan <font color="#f00">*</font>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="no_spb" name="no_spb" readonly="readonly"
                                class="form-control myline" style="margin-bottom:5px" 
                                value="Auto generate">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Tanggal <font color="#f00">*</font>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="tanggal" name="tanggal" 
                                class="form-control myline input-small" style="margin-bottom:5px;float:left;" 
                                value="<?php echo date('d-m-Y'); ?>">
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-md-4">
                            PIC
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="nama_penimbang" name="nama_penimbang" 
                                class="form-control myline" style="margin-bottom:5px" readonly="readonly" value="<?php echo $this->session->userdata('realname'); ?>">
                        </div>
                    </div>
                    <div class="row">&nbsp;</div>
                    <div class="row">
                        <div class="col-md-4">&nbsp;</div>
                        <div class="col-md-8">
                            <a href="javascript:;" class="btn green" onclick="simpanData();"> 
                                <i class="fa fa-floppy-o"></i> Input Details </a>
                        </div>    
                    </div>
                </div>
                <div class="col-md-1">&nbsp;</div>
                <div class="col-md-5">
                    <div class="row">
                        <div class="col-md-4">
                            No. Surat Jalan
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="surat_jalan" id="surat_jalan" class="form-control myline" onkeyup="this.value = this.value.toUpperCase()" style="margin-bottom: 5px">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Peminjaman Oleh
                        </div>
                        <div class="col-md-8">
                            <select id="peminjaman" name="peminjaman" placeholder="Silahkan pilih..." class="form-control myline select2me" style="margin-bottom:5px;" onchange="pilih_data(this.value);">
                                <option></option>
                                <option value="Customer">Customer</option>
                                <option value="Supplier">Supplier</option> 
                            </select>
                        </div>
                    </div>
                    <div class="row hidden disabled" id="show_supplier">
                        <div class="col-md-4">
                            Supplier
                        </div>
                        <div class="col-md-8">
                            <select id="supplier_id" name="supplier_id" class="form-control myline select2me" 
                                data-placeholder="Silahkan pilih..." style="margin-bottom:5px" onchange="get_surat_jalan_supplier(this.value);">
                                <option value=""></option>
                                <?php
                                    foreach ($supplier_list as $row){
                                        echo '<option value="'.$row->id.'">'.$row->nama_supplier.'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row hidden disabled" id="show_customer">
                        <div class="col-md-4">
                            Customer
                        </div>
                        <div class="col-md-8">
                            <select id="m_customer_id" name="m_customer_id" class="form-control myline select2me" 
                                data-placeholder="Silahkan pilih..." style="margin-bottom:5px">
                                <option value=""></option>
                                <?php
                                    foreach ($customer_list as $row){
                                        echo '<option value="'.$row->id.'">'.$row->nama_customer.'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <!-- <div class="row">
                        <div class="col-md-4">
                            No. Surat Peminjaman
                        </div>
                        <div class="col-md-8">
                            <select id="surat_peminjaman_id" name="surat_peminjaman_id" placeholder="Silahkan pilih..."
                                class="form-control myline select2me" style="margin-bottom:5px;">
                                <option value=""></option>  
                            </select>
                        </div>
                    </div> -->
                    <div class="row">
                        <div class="col-md-4">
                            Catatan
                        </div>
                        <div class="col-md-8">
                            <textarea id="remarks" name="remarks" rows="2" onkeyup="this.value = this.value.toUpperCase()"
                                class="form-control myline" style="margin-bottom:5px"></textarea>                           
                        </div>
                    </div>
                </div>              
            </div>
        </form>
        
        <?php
            }else{
        ?>
        <div class="alert alert-danger">
            <button class="close" data-close="alert"></button>
            <span id="message">Anda tidak memiliki hak akses ke halaman ini!</span>
        </div>
        <?php
            }
        ?>
    </div>
</div> 
<script>
function pilih_data(id){
    if(id == 'Supplier'){
        $('#show_supplier').removeClass('hidden disabled');
        $('#supplier_id').removeClass('disabled');
        $('#supplier_id').select2('val','');
        $('#m_customer_id').select2('val', '');
        $('#m_customer_id').addClass('disabled');
        $('#show_customer').addClass('hidden disabled');
    }else if(id == 'Customer'){
        $('#show_supplier').addClass('hidden disabled');
        $('#supplier_id').addClass('disabled');
        $('#supplier_id').select2('val','');
        $('#m_customer_id').select2('val', '');
        $('#m_customer_id').removeClass('disabled');
        $('#show_customer').removeClass('hidden disabled');
    }
}

function get_surat_jalan_supplier(id){
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('index.php/GudangBobbin/get_sj_list_supplier'); ?>",
        data: "id="+id,
        dataType: "html",
        success: function(result) {
            $('#surat_peminjaman_id').html(result);
        }
    });
}

function get_surat_jalan_customer(id){
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('index.php/GudangBobbin/get_sj_list'); ?>",
        data: "id="+id,
        dataType: "html",
        success: function(result) {
            $('#surat_peminjaman_id').html(result);
        }
    });
}

function simpanData(){
    if($.trim($("#tanggal").val()) == ""){
        $('#message').html("Tanggal harus diisi, tidak boleh kosong!");
        $('.alert-danger').show(); 
    }else{     
        $('#formku').submit(); 
    };
};
</script>

<link href="<?php echo base_url(); ?>assets/css/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url(); ?>assets/js/jquery-1.12.4.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script>
$(function(){        
    $("#tanggal").datepicker({
        showOn: "button",
        buttonImage: "<?php echo base_url(); ?>img/Kalender.png",
        buttonImageOnly: true,
        buttonText: "Select date",
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy'
    });       
});
</script>
      