<?php
class Model_bobbin extends CI_Model{
    function list_data(){
        $data = $this->db->query("");
        return $data;
    }

    function get_owner_list(){
        $data = $this->db->query("");
        return $data;
    }

    function get_size_list(){
        $data = $this->db->query("");
        return $data;
    }
}