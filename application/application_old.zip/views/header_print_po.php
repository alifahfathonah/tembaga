		<?php if($this->session->userdata('user_ppn')!=1){ ?>
        <h2>PT. KAWATMAS PRAKASA<br></h2>
        <p style="margin-top: -15px">
            JL. HALIM PERDANA KUSUMA NO. 51 Kebon Besar Batu Ceper Tangerang<br>
            TLP. : (021) 5523547, 5453625 - 26  FAX. (021) 5523548<br>
            Email : kawatmas@kawatmas.co.id<br>
        </p>
        <?php } ?>
        <h2 align="center"><u>SURAT PESANAN</u></h2>
        <h3 align="center" style="margin-top: -10px;">PURCHASE ORDER</h3>
        <div class="row">
        	<div class="col-md-6">
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        	</div>
        	<div class="col-md-6">
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        		<div class="row">
        			<div class="col-md-2">Kepada Yth.</div>
        			<div class="col-md-4">: Value</div>
        		</div>
        	</div>
        </div>