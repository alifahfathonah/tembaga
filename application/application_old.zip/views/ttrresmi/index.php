<div class="row">
    <div class="col-md-12 alert-warning alert-dismissable">        
        <h4 style="color:navy">
            <a href="<?php echo base_url(); ?>"> <i class="fa fa-home"></i> Home </a> 
            <i class="fa fa-angle-right"></i> TTR Resmi 
            <a href="<?php echo base_url('index.php/ProsesResmi'); ?>"> TTR RESMI </a>
        </h4>          
    </div>
</div>
<div class="row">&nbsp;</div>
<div class="row">                            
    <div class="col-md-12"> 
        <div class="modal fade" id="myModal" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                        <h4 class="modal-title">&nbsp;</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-danger display-hide">
                                    <button class="close" data-close="alert"></button>
                                    <span id="message">&nbsp;</span>
                                </div>
                            </div>
                        </div>
                        <form class="eventInsForm" method="post" target="_self" name="formku" 
                              id="formku">                            
                            <div class="row">
                                <div class="col-md-5">
                                    Nama Barang <font color="#f00">*</font>
                                </div>
                                <div class="col-md-7">
                                    <input placeholder="Masuka nama barang..." type="text" id="nama_barang" name="nama_barang" 
                                        class="form-control myline" style="margin-bottom:5px">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-md-5">
                                    QTY <font color="#f00">*</font>
                                </div>
                                <div class="col-md-7">
                                    <input placeholder="Masukan QTY..." type="text" id="qty" name="qty" 
                                        class="form-control myline" style="margin-bottom:5px">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-md-5">
                                    Harga Satuan <font color="#f00">*</font>
                                </div>
                                <div class="col-md-7">
                                    <input placeholder="Masukan harga satuan..." type="text" id="harga_satuan" name="harga_satuan" 
                                        class="form-control myline" style="margin-bottom:5px">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    Total Harga <font color="#f00">*</font>
                                </div>
                                <div class="col-md-7">
                                    <input placeholder="Masukan total harga..." type="text" id="total_harga" name="total_harga" 
                                        class="form-control myline" style="margin-bottom:5px">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-md-5">
                                    PPN <font color="#f00">*</font>
                                </div>
                                <div class="col-md-7">
                                    <input placeholder="Masukan ppn.." type="text" id="ppn" name="ppn" 
                                        class="form-control myline" style="margin-bottom:5px">
                                </div>
                            </div>    
                        </form>
                    </div>
                    <div class="modal-footer">                        
                        <button type="button" class="btn blue" onClick="simpandata();">Simpan</button>
                        <button type="button" class="btn default" data-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
          <div class="col-md-6">
                <div class="alert alert-success <?php echo (empty($this->session->flashdata('flash_msg'))? "display-hide": ""); ?>" id="box_msg_sukses">
                    <button class="close" data-close="alert"></button>
                    <span id="msg_sukses"><?php echo $this->session->flashdata('flash_msg'); ?></span>
                </div>
            
        <div class="portlet box yellow-gold">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-beer"></i>TTR RESMI
                </div>
                <div class="tools">    
                    <!--a style="height:28px" class="btn btn-circle btn-sm blue-ebonyclay" onclick="newData()">
                        <i class="fa fa-plus"></i> Tambah</a-->
                </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_6">
                <thead>
                <tr>
                    
                    <th style="width:50px;">No</th>
                    <th>Tanggal</th> 
                    <th>QTY</th> 
                    
                    
                    <th></th>
                </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 0;
                        foreach ($list_data as $data){
                            $no++;
                    ?>
                    <tr>

                        <td style="text-align:center"><?php echo $no; ?></td>
                        <td><?php echo $data->tanggal; ?></td>
                        <td><?php echo $data->qty; ?></td>
                        
                    <td> 
                     <a href="<?= base_url();?>index.php/kirim/save/<?=$data->ids;?>/<?=$data->tanggal;?>/<?=$data->qty;?>"> Move 
                    </td>
                    </tr>
                    <?php
                        }
                    ?>                                                                                    
                </tbody>
                </table>
            </div>
        </div>
    
    </div>

     <div class="col-md-6">
                
            
        <div class="portlet box yellow-gold">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-beer"></i>MOVE
                </div>
                <div class="tools">    
                    <!--a style="height:28px" class="btn btn-circle btn-sm blue-ebonyclay" onclick="newData()">
                        <i class="fa fa-plus"></i> Tambah</a-->
                </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_6">
                <thead>
                <tr>
                    
                    <th style="width:50px;">No</th>
                    <th>Tanggal</th> 
                    <th>QTY</th> 
                   
                </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 0;
                        foreach ($list_data2 as $data2){
                            $no++;
                    ?>
                    <tr>

                        <td style="text-align:center"><?php echo $no; ?></td>
                        <td><?php echo $data2->tanggal; ?></td>
                        <td><?php echo $data2->qty; ?></td>
                       
                    </tr>
                    <?php
                        }
                    ?>                                                                                    
                </tbody>
                </table>
            </div>
        </div>



        <button class="btn blue" onclick="invoice()"> Cetak Invoice </button>
        

    </div>

      
</div>


        <script type="text/javascript">
            function invoice(){

                document.getElementById('view').innerHTML="<div class='col-md-12'><h3>Invoice</h3><form method='post' action='<?= base_url(); ?>index.php/PrintInvoice' target='_blank'><div class='form-group'><label for='exampleInputEmail1'>Textield</label><input type='text' class='form-control' id='exampleInputEmail1' aria-describedby='emailHelp' placeholder='Enter Text' name='name1'></div><div class='form-group'><label for='exampleInputPassword1'>Texfield</label><input type='text' class='form-control' id='exampleInputPassword1' placeholder='Textfield' name='name2'></div><div class='form-check'></label></div><button type='submit' class='btn btn-primary' type='submit'>Print</button></form></div>";


            }

            
        </script>    

<span  id="view" ></span>


<link href="<?php echo base_url(); ?>assets/css/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url(); ?>assets/js/jquery-1.12.4.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script>
function myCurrency(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 95 || charCode > 105))
        return false;
    return true;
}

function getComa(value, id){
    angka = value.toString().replace(/\./g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, "."));
}

function newData(){
    $('#nama_barang').val('');
    $('#qty').val('');
    $('#harga_satuan').val('');
    $('#Total_harga').val('');
    $('#ppn').val('');
    
    $('#message').html("");
    $('.alert-danger').hide(); 
    
    $("#myModal").find('.modal-title').text('Input Proses Resmi');
    $("#myModal").modal('show',{backdrop: 'true'}); 
}

function simpandata(){
   
   
        $('#formku').attr("action", "<?php echo base_url(); ?>index.php/ProsesResmi/save");
        $('#formku').submit();                                  
 


}

</script>         