				<div class="row">
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
					<div class="col-md-2">
						Jumlah
					</div>
					<div class="col-md-10">
						: Value
					</div>
				</div>