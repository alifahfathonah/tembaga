<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('target_url'))
{
	function target_url(){
		$url = 'http://localhost/tembaga_resmi/index.php/';
		return $url;
	}
}