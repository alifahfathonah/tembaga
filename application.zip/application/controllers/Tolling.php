<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tolling extends CI_Controller{
    function __construct(){
        parent::__construct();

        if($this->session->userdata('status') != "login"){
            redirect(base_url("index.php/Login"));
        }
    }
    
    function index(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');
        $ppn         = $this->session->userdata('user_ppn');
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/index";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->so_list($ppn)->result();

        $this->load->view('layout', $data);
    }
    
    function add(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;
        $data['content']= "tolling_titipan/add";
        
        $this->load->model('Model_tolling_titipan');
        $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
        // $data['marketing_list'] = $this->Model_tolling_titipan->marketing_list()->result();
        $this->load->view('layout', $data);
    }
    
    function get_contact_name(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->get_contact_name($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data); 
    }

    function get_cp(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $barang= $this->Model_tolling_titipan->get_cp($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($barang); 
    }
    
    function save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tgl_po = date('Y-m-d', strtotime($this->input->post('tanggal_po')));
        $user_ppn  = $this->session->userdata('user_ppn');
        
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('SO', $tgl_input); 
        
        if($code){        
            $data = array(
                'no_sales_order'=> $code,
                'tanggal'=> $tgl_input,
                'flag_tolling'=> 1,
                'flag_ppn'=>$user_ppn,
                'm_customer_id'=>$this->input->post('m_customer_id'),
                'marketing_id'=>$this->input->post('marketing_id'),
                'created'=> $tanggal,
                'created_by'=> $user_id,
                'modified'=> $tanggal,
                'modified_by'=> $user_id
            );
            $this->db->insert('sales_order', $data);
            $so_id = $this->db->insert_id();
            if($this->input->post('jenis_barang') == 'FG'){
            $num = $this->Model_m_numberings->getNumbering('SPB-FG', $tgl_input); 
                $dataC = array(
                    'no_spb'=> $num,
                    'tanggal'=> $tgl_input,
                    'keterangan'=>'TOLLING SO FINISH GOOD',
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                );
                $this->db->insert('t_spb_fg', $dataC);
                $insert_id = $this->db->insert_id();
            }else{
            $num = $this->Model_m_numberings->getNumbering('SPB-WIP', $tgl_input);
                $dataC = array(
                    'no_spb_wip'=> $num,
                    'tanggal'=> $tgl_input,
                    'keterangan'=> 'TOLLING SO WIP',
                    'created'=> $tanggal,
                    'created_by'=> $user_id
                );
                $this->db->insert('t_spb_wip', $dataC);
                $insert_id = $this->db->insert_id();
            }

            $t_data = array(
                'alias'=>$this->input->post('alias'),
                'so_id'=>$so_id,
                'no_po'=>$this->input->post('no_po'),
                'tgl_po'=>$tgl_po,
                'no_spb'=>$insert_id,
                'jenis_barang'=> $this->input->post('jenis_barang'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            );

            if($this->db->insert('t_sales_order', $t_data)){
                redirect('index.php/Tolling/edit/'.$so_id);  
            }else{
                $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, silahkan dicoba kembali!');
                redirect('index.php/Tolling');  
            }            
        }else{
            $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, penomoran belum disetup!');
            redirect('index.php/Tolling');
        }
    }    

    function view(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/view";
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_so($id)->row_array();
            $data['detail'] = $this->Model_tolling_titipan->load_detail_edit($id)->result(); 
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }
    
    function edit(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/edit";
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_so($id)->row_array();  
            $jenis = $data['header']['jenis_barang'];          
            $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
            // $data['marketing_list'] = $this->Model_tolling_titipan->marketing_list()->result();
                $data['list_barang'] = $this->Model_tolling_titipan->jenis_barang($jenis)->result();
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }
    
    function update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');        
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tgl_po = date('Y-m-d', strtotime($this->input->post('tanggal_po')));
        $data = array(
                'tanggal'=> $tgl_input,
                'm_customer_id'=>$this->input->post('m_customer_id'),
                'marketing_id'=>$this->input->post('marketing_id'),
                'keterangan'=>$this->input->post('keterangan'),
                'modified'=> $tanggal,
                'modified_by'=> $user_id
            );
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('sales_order', $data);

        $this->db->where('so_id', $this->input->post('id'));
        $this->db->update('t_sales_order', array(
            'no_po' => $this->input->post('no_po'),
            'tgl_po' => $tgl_po
        ));
        
        $this->session->set_flashdata('flash_msg', 'Data sales order berhasil disimpan');
        redirect('index.php/Tolling');
    }
    
    function load_detail(){
        $id = $this->input->post('id');
        
        $tabel = "";
        $no    = 1;
        $total = 0;
        $bruto = 0;
        $netto = 0;
        
        $this->load->model('Model_tolling_titipan'); 
        $myDetail = $this->Model_tolling_titipan->load_detail_edit($id)->result(); 
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';
            $tabel .= '<td>'.$row->jenis_barang.'</td>';
            $tabel .= '<td>'.$row->uom.'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->amount,0,',','.').'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->netto,0,',','.').'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->total_amount,0,',','.').'</td>';
            $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
                    . 'red" onclick="hapusDetail('.$row->id.','.$row->no_spb_detail.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a></td>';
            $tabel .= '</tr>';
            $total += $row->total_amount;
            $netto += $row->netto;
            $no++;
        }    
        
        $tabel .= '<tr>';
        $tabel .= '<td colspan="4" style="text-align:right"><strong>Total </strong></td>';
        $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($netto,0,',','.').'</strong></td>';
        $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($total,0,',','.').'</strong></td>';
        $tabel .= '<td></td>';
        $tabel .= '</tr>';
       
        
        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }
    
    function get_uom(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $rongsok= $this->Model_tolling_titipan->get_uom($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($rongsok); 
    }
    
    function save_detail(){
        $return_data = array();
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        if($this->input->post('jb') == 'FG'){
            $dataC = array(
                't_spb_fg_id'=>$this->input->post('id_spb'),
                'tanggal'=>$tanggal,
                'jenis_barang_id'=>$this->input->post('jenis_barang'),
                'uom'=>$this->input->post('uom'),
                'netto'=> str_replace('.', '', $this->input->post('netto')),
                'keterangan'=>'SO TOLLING'
            );
            $this->db->insert('t_spb_fg_detail', $dataC);
            $insert_id = $this->db->insert_id();
        }else{
            $dataC = array(
                't_spb_wip_id'=> $this->input->post('id_spb'),
                'tanggal'=> $tanggal,
                'jenis_barang_id'=> $this->input->post('jenis_barang'),
                'uom'=> $this->input->post('uom'),
                'qty'=>str_replace('.', '', $this->input->post('netto')),
                'berat'=> str_replace('.', '', $this->input->post('netto')),
                'keterangan'=> 'SO TOLLING'
            );
            $this->db->insert('t_spb_wip_detail', $dataC);
            $insert_id = $this->db->insert_id();
        }
        
        if($this->db->insert('t_sales_order_detail', array(
            't_so_id'=>$this->input->post('id'),
            'no_spb_detail'=> $insert_id,
            'jenis_barang_id'=>$this->input->post('jenis_barang'),
            'netto'=>str_replace('.', '', $this->input->post('netto')),
            'amount'=>str_replace('.', '', $this->input->post('harga')),
            'total_amount'=>str_replace('.', '', $this->input->post('total_harga'))
        ))){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item rongsok! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }
    
    function delete_detail(){
        $id = $this->input->post('id');
        $id_spb = $this->input->post('id_spb');
        $return_data = array();

        if($this->input->post('jb') == 'FG'){
            $this->db->where('id', $id_spb);
            $this->db->delete('t_spb_fg_detail');
        }else{
            $this->db->where('id', $id_spb);
            $this->db->delete('t_spb_wip_detail');
        }

        $this->db->where('id', $id);
        if($this->db->delete('t_sales_order_detail')){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menghapus item rongsok! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function matching(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');   
        $user_ppn = $this->session->userdata('user_ppn');     
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/matching";
        $this->load->model('Model_tolling_titipan');
        $data['po_list'] = $this->Model_tolling_titipan->get_po_list($user_ppn)->result();

        $this->load->view('layout', $data);
    }

    function proses_matching(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $po_id = $this->uri->segment(3);
        
        $data['content']= "tolling_titipan/proses_matching";
        $this->load->model('Model_tolling_titipan');
        $this->load->model('Model_beli_fg');
        $data['header_po'] = $this->Model_tolling_titipan->show_header_po($po_id)->row_array();
        $data['details_po'] = $this->Model_beli_fg->show_detail_po($po_id)->result();

        $dtt_app = $this->Model_tolling_titipan->get_dtt_approve($po_id)->result();
        foreach ($dtt_app as $index=>$row){
            $dtt_app[$index]->details = $this->Model_tolling_titipan->show_detail_dtt($row->id)->result();
        }
        $data['dtt_app'] = $dtt_app;
        $jenis = $data['header_po']['jenis_po'];
        $customer_id = $data['header_po']['customer_id'];
        $dtt = $this->Model_tolling_titipan->get_dtt($customer_id,$jenis)->result();
        foreach ($dtt as $index=>$row){
            $dtt[$index]->details = $this->Model_tolling_titipan->show_detail_dtt($row->id)->result();
        }
        $data['dtt'] = $dtt;
        $this->load->view('layout', $data);
    }

    function approve_matching_dtt(){
        $dtt_id = $this->input->post('dtt_id');
        $po_id = $this->input->post('po_id');
        $jenis = $this->input->post('jenis_barang');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d');
        $return_data = array();
        $this->load->model('Model_tolling_titipan');
        
        $this->db->trans_start();       

            #Update status DTBJ
            $this->db->where('id', $dtt_id);
            $this->db->update('dtt', array(
                    'po_id'=>$po_id,
                    'status'=>1,
                    'approved'=>$tanggal,
                    'approved_by'=>$user_id));
                
                #update po_detail_id di dtbj_detail
                $po_dtt_check_update = $this->Model_tolling_titipan->check_to_update($po_id)->result();
                foreach ($po_dtt_check_update as $u){
                    $this->db->where('id',$u->dtt_detail_id );
                    $this->db->update('dtt_detail',array(
                                    'po_detail_id'=>$u->id));
                }

                $total_qty = 0;
                $total_netto_dtt = 0;
                $po_dtt_list = $this->Model_tolling_titipan->check_po_dtt($po_id)->result();
                foreach ($po_dtt_list as $v) {
                    #penghitungan +- 10 % PO ke DTR
                    if(((int)$v->tot_netto) >= (0.9*((int)$v->tot_qty))){
                        #update po_detail flag_dtr
                        $this->Model_tolling_titipan->update_flag_dtt_po_detail($po_id);
                    }
                    $total_qty += $v->tot_qty;
                    $total_netto_dtt += $v->tot_netto;
                }

               if(((int)$total_netto_dtt) >= (0.9*((int)$total_qty))){
                    $this->db->where('id',$po_id);
                    $this->db->update('po',array(
                                    'status'=>3));
               }else {
                    $this->db->where('id',$po_id);
                    $this->db->update('po',array(
                                    'status'=>2));
               }

            #Create BPB
                $this->load->model('Model_m_numberings');
                $code = $this->Model_m_numberings->getNumbering('BPB-PO-T',$tgl_input);
                $loop1 = $this->db->query("select dttd.dtt_id, dttd.jenis_barang_id, jb.jenis_barang
                    from dtt_detail dttd
                    left join jenis_barang jb on (jb.id = dttd.jenis_barang_id)
                    where dttd.dtt_id =".$dtt_id." group by jb.jenis_barang")->result();
            if($jenis == 'FG'){
                foreach ($loop1 as $k1) {
                    #insert t_bpb_fg
                    $data_bpb = array(
                            'no_bpb_fg' => $code,
                            'tanggal' => $tgl_input,
                            'jenis_barang_id' => $k1->jenis_barang_id,
                            'created_at' => $tanggal,
                            'created_by' => $user_id,
                            'keterangan' => 'BARANG PO FG',
                            'status' => 0
                        );
                    $this->db->insert('t_bpb_fg',$data_bpb);
                    $id_bpb = $this->db->insert_id();

                    #insert t_bpb_detail
                    $loop2 = $this->db->query("select dtt_detail.*, m_bobbin.id as bobbin_id from dtt_detail left join m_bobbin on (m_bobbin.nomor_bobbin = dtt_detail.no_bobbin) where jenis_barang_id =".$k1->jenis_barang_id." and dtt_id = ".$dtt_id)->result();
                    foreach ($loop2 as $k2) {
                        $this->db->insert('t_bpb_fg_detail', array(
                            't_bpb_fg_id' => $id_bpb,
                            'jenis_barang_id' => $k2->jenis_barang_id,
                            'no_produksi' => 0,
                            'bruto' => $k2->bruto,
                            'netto' => $k2->netto,
                            'no_packing_barcode' => $k2->no_packing,
                            'bobbin_id' => $k2->bobbin_id
                        ));
                    }
                }
            }else if($jenis == 'WIP'){
                #Create BPB WIP
                foreach ($loop1 as $k1) {
                    #insert t_bpb_fg
                    $data_bpb = array(
                            'no_bpb' => $code,
                            'created' => $tanggal,
                            'created_by' => $user_id,
                            'keterangan' => 'BARANG PO WIP',
                            'status' => 0
                        );
                    $this->db->insert('t_bpb_wip',$data_bpb);
                    $id_bpb = $this->db->insert_id();

                    #insert t_bpb_detail
                    $loop2 = $this->db->query("select dtt_detail.*, jb.uom from dtt_detail left join jenis_barang jb on (jb.id = dtt_detail.jenis_barang_id) where jenis_barang_id =".$k1->jenis_barang_id." and dtt_id =".$dtt_id)->result();
                    foreach ($loop2 as $k2) {
                        $this->db->insert('t_bpb_wip_detail', array(
                            'bpb_wip_id' => $id_bpb,
                            'created' => $tgl_input,
                            'jenis_barang_id' => $k2->jenis_barang_id,
                            'qty' => $k2->qty,
                            'berat' => $k2->netto,
                            'uom' => $k2->uom,
                            'keterangan' => $k2->line_remarks,
                            'created_by' => $user_id
                        ));
                    }
                }
            }

        if($this->db->trans_complete()){ 
            $return_data['type_message']= "sukses";
            $return_data['message'] = "DTT sudah diberikan ke bagian gudang";           
        }else{
            $return_data['type_message']= "error";
            $return_data['message']= "Pembuatan DTT gagal, penomoran belum disetup!";
        }                  
        
       header('Content-Type: application/json');
       echo json_encode($return_data);
    }

    function reject_matching_dtt(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        
        $data = array(
                'status'=> 9,
                'rejected'=> $tanggal,
                'rejected_by'=>$user_id,
                'reject_remarks'=>$this->input->post('reject_remarks')
            );
        
        $this->db->where('id', $this->input->post('dtbj_id'));
        $this->db->update('dtbj', $data);

        $query = $this->db->query('select *from dtbj_detail where dtbj_id = '.$this->input->post('dtbj_id'))->result();
        foreach ($query as $row) {
            $this->db->where('nomor_bobbin', $row->no_bobbin);
            $this->db->update('m_bobbin', array(
                'status' => 3
            ));
        }

        redirect('index.php/BeliFinishGood/proses_matching/'.$this->input->post('po_id'));
    }

    function matching_so(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $so_id = $this->uri->segment(3);
        
        $data['content']= "tolling_titipan/matching_so";
        $this->load->model('Model_tolling_titipan');
        $data['header_so']  = $this->Model_tolling_titipan->show_header_so($so_id)->row_array();
        $data['details_so'] = $this->Model_tolling_titipan->show_detail_so($so_id)->result();

        $dtr_app = $this->Model_tolling_titipan->get_dtr_approve($so_id)->result();
        foreach ($dtr_app as $index=>$row){
            $dtr_app[$index]->details = $this->Model_tolling_titipan->show_detail_dtr($row->id)->result();
        }
        $data['dtr_app'] = $dtr_app;
        $c_id = $data['header_so']['m_customer_id'];
        $dtr = $this->Model_tolling_titipan->get_dtr($c_id)->result();
        foreach ($dtr as $index=>$row){
            $dtr[$index]->details = $this->Model_tolling_titipan->show_detail_dtr($row->id)->result();
        }
        $data['dtr'] = $dtr;
        $this->load->view('layout', $data);
    }

    function approve_matching(){
        $dtr_id = $this->input->post('dtr_id');
        $so_id = $this->input->post('so_id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d');
        $return_data = array();
        
            $this->db->trans_start();       
            #Update status DTR
            $this->db->where('id', $dtr_id);
            $this->db->update('dtr', array(
                    'so_id'=>$so_id,
                    'status'=>1,
                    'approved'=>$tanggal,
                    'approved_by'=>$user_id));
            
            #Create TTR
            $data = array(
                    'tanggal'=> $tgl_input,
                    'dtr_id'=> $dtr_id,
                    'ttr_status' => 0,
                    'created'=> $tanggal,
                    'created_by'=> $user_id,
                    'modified'=> $tanggal,
                    'modified_by'=> $user_id
            );
            $this->db->insert('ttr', $data);
            $ttr_id = $this->db->insert_id();
            
            $this->load->model('Model_beli_rongsok');
            $details = $this->Model_beli_rongsok->show_detail_dtr($dtr_id)->result();
            foreach ($details as $row){
                $this->db->insert('ttr_detail', array(
                    'ttr_id'=>$ttr_id,
                    'dtr_detail_id'=>$row->id,
                    'rongsok_id'=>$row->rongsok_id,
                    'qty'=>$row->qty,
                    'bruto'=>$row->bruto,
                    'netto'=>$row->netto,
                    'line_remarks'=>$row->line_remarks,
                    'created'=>$tanggal,
                    'created_by'=> $user_id,
                    'modified'=> $tanggal,
                    'modified_by'=> $user_id
                ));
            }
            
            if($this->db->trans_complete()){  
                $this->load->model('Model_tolling_titipan');
            
                #update status PO, jika DTR sudah mencukupi
                $so_dtr_list = $this->Model_tolling_titipan->check_so_dtr($so_id)->result();
                foreach ($so_dtr_list as $v) {
                    #penghitungan +- 10 % PO ke DTR
                    // if(((int)$v->tot_netto) >= (0.9*((int)$v->qty))){
                    //     #update po_detail flag_dtr
                    //     $this->Model_beli_rongsok->update_flag_dtr_po_detail($po_id);
                    // }
                    // $total_qty += $v->qty;
                        if(((int)$v->tot_netto) >= (0.9*((int)$v->tot_qty))){
                            $this->db->where('id',$so_id);
                            $this->db->update('sales_order',array(
                                            'flag_tolling'=>2));
                        }else {
                            $this->db->where('id',$so_id);
                            $this->db->update('sales_order',array(
                                            'flag_tolling'=>1));
                        }
                }

            $return_data['type_message']= "sukses";
            $return_data['message'] = "TTR sudah diberikan ke bagian gudang";
                //$return_data['message']= "TTR berhasil di-create dengan nomor : ".$code;                 
        }else{
            $return_data['type_message']= "error";
            $return_data['message']= "Pembuatan TTR gagal, penomoran belum disetup!";
        }                  
        
       header('Content-Type: application/json');
       echo json_encode($return_data);
    }

    function print_so(){
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_so($id)->row_array();
            $data['details'] = $this->Model_tolling_titipan->show_detail_so($id)->result();

            $this->load->view('tolling_titipan/print_so', $data);
        }else{
            redirect('index.php'); 
        }
    }

    function get_uom_so(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $rongsok= $this->Model_tolling_titipan->get_uom($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($rongsok); 
    }

     function load_detail_dtr(){
        $id = $this->input->post('id');
        
        $tabel = "";
        $no    = 1;
        $this->load->model('Model_tolling_titipan');
        $list_tolling_so = $this->Model_tolling_titipan->list_data_on_so($id)->result();
        
        $myDetail = $this->Model_tolling_titipan->load_detail_saved($id)->result(); 
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';
            $tabel .= '<td>'.$row->nama_item.'</td>';
            $tabel .= '<td>'.$row->uom.'</td>';
            $tabel .= '<td>'.$row->bruto.'</td>';
            $tabel .= '<td>'.$row->berat_palette.'</td>';
            $tabel .= '<td>'.$row->netto.'</td>';
            $tabel .= '<td>'.$row->no_pallete.'</td>';
            $tabel .= '<td>'.$row->line_remarks.'</td>';
            $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
                    . 'red" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a></td>';
            $tabel .= '</tr>';            
            $no++;
        }
            
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:center">'.$no.'</td>';
        $tabel .= '<input type="hidden" id="so_id" name="so_id" value="'.$id.'" class="form-control myline"/>';
        $tabel .= '<td><select id="rongsok_id" name="rongsok_id" class="form-control select2me myline" ';
            $tabel .= 'data-placeholder="Pilih..." style="margin-bottom:5px" onchange="get_uom_so(this.value);">';
            $tabel .= '<option value=""></option>';
            foreach ($list_tolling_so as $value){
                $tabel .= "<option value='".$value->id."'>".$value->nama_item."</option>";
            }
        $tabel .= '<td><input type="text" id="uom" name="uom" class="form-control myline" readonly></td>';
        $tabel .= '<td><input type="text" id="bruto" name="bruto" class="form-control myline"/></td>';
        $tabel .= '<td><input type="text" id="berat_palette" name="berat_palette" class="form-control myline"/></td>';
        $tabel .= '<td><input type="text" id="netto" name="netto" readonly="readonly" class="form-control myline"/></td>';
        $tabel .= '<td><input type="text" id="no_pallete" name="no_pallete" class="form-control myline" onkeyup="this.value = this.value.toUpperCase()"/></td>';
        $tabel .= '<td><input type="text" id="keterangan" name="keterangan" class="form-control myline" '
                . 'onkeyup="this.value = this.value.toUpperCase()"></td>';        
        $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
                . 'yellow-gold" onclick="saveDetail();" style="margin-top:5px" id="btnSaveDetail"> '
                . '<i class="fa fa-plus"></i> Tambah </a></td>';
        $tabel .= '</tr>';
        
        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    function save_so_detail(){
        $return_data = array();
        $tgl_input = date("Y-m-d");
        
        if($this->db->insert('dtr_detail', array(
            'so_id' => $this->input->post('so_id'),
            'rongsok_id' => $this->input->post('rongsok_id'),
            'qty' => $this->input->post('qty'),
            'bruto' => $this->input->post('bruto'),
            'netto' => $this->input->post('netto'),
            'no_pallete' => $this->input->post('no_palette'),
            'berat_palette' => $this->input->post('berat_palette'),
            'line_remarks' => $this->input->post('keterangan')
        ))){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item barang! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    function delete_detail_so(){
        $id = $this->input->post('id');
        $return_data = array();
        $this->db->where('id', $id);
        if($this->db->delete('dtr_detail')){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menghapus item barang! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function create_dtr(){
        $module_name = $this->uri->segment(1);
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/create_dtr";
            $this->load->model('Model_beli_rongsok');
            $data['list_rongsok_on_po'] = $this->Model_beli_rongsok->show_data_rongsok()->result();
            $this->load->model('Model_tolling_titipan');
            $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
            $this->load->view('layout', $data);
    }
    
    function save_dtr(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $user_ppn = $this->session->userdata('user_ppn');

        $this->db->trans_start();
        $this->load->model('Model_m_numberings');
        if($user_ppn==1){
            $code = $this->Model_m_numberings->getNumbering('DTR-TKMP', $tgl_input);
        }else{
            $code = $this->Model_m_numberings->getNumbering('DTR-T', $tgl_input);
        }
        $this->load->model('Model_tolling_titipan');

        if($code){        
            $data = array(
                        'no_dtr'=> $code,
                        'flag_ppn'=> $user_ppn,
                        'tanggal'=> $tgl_input,
                        'customer_id'=> $this->input->post('supplier_id'),
                        'jenis_barang'=> $this->input->post('jenis_barang'),
                        'remarks'=> $this->input->post('remarks'),
                        'created'=> $tanggal,
                        'created_by'=> $user_id,
                        'modified'=> $tanggal,
                        'modified_by'=> $user_id
                    );
            $this->db->insert('dtr', $data);
            $dtr_id = $this->db->insert_id();
            $details = $this->input->post('myDetails');
            foreach ($details as $row){
                if($row['rongsok_id']!=''){
                    $this->db->insert('dtr_detail', array(
                        'dtr_id'=>$dtr_id,
                        'rongsok_id'=>$row['rongsok_id'],
                        // 'qty'=>str_replace('.', '', $row['qty']),
                        'bruto'=>$row['bruto'],
                        'berat_palette'=>$row['berat_palette'],
                        'netto'=>$row['netto'],
                        'no_pallete'=>$row['no_pallete'],
                        'line_remarks'=>$row['line_remarks'],
                        'created'=>$tanggal,
                        'created_by'=>$user_id,
                        'tanggal_masuk'=>$tgl_input
                    ));
                }
            }   
            
            if($this->db->trans_complete()){    
                $this->session->set_flashdata('flash_msg', 'DTR berhasil di-create dengan nomor : '.$code);                 
            }else{
                $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat create DTR, silahkan coba kembali!');
            }                   
        }else{
            $this->session->set_flashdata('flash_msg', 'Pembuatan DTR gagal, penomoran belum disetup!');
        }
        redirect('index.php/Tolling/dtr_list');    
    }
    
    function dtr_list(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');
        $user_ppn    = $this->session->userdata('user_ppn');
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/dtr_list";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->dtr_list($user_ppn)->result();

        $this->load->view('layout', $data);
    }
    
    function print_dtr(){
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_dtr($id)->row_array();
            $data['details'] = $this->Model_tolling_titipan->show_detail_dtr($id)->result();

            $this->load->view('print_dtr_from_so', $data);
        }else{
            redirect('index.php'); 
        }
    }
    
    function view_dtr(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/view_dtr";
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_dtr($id)->row_array(); 
            $data['details'] = $this->Model_tolling_titipan->show_detail_dtr($id)->result();
            
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }
    
    function approve(){
        $dtr_id = $this->input->post('dtr_id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d');
        
        $return_data = array();
        $this->db->trans_start(); 
        
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('TTR', $tgl_input); 
        if($code){ 
            #Update status DTR
            $this->db->where('id', $dtr_id);
            $this->db->update('dtr', array(
                    'status'=>1,
                    'approved'=>$tanggal,
                    'approved_by'=>$user_id));
            
            #Create TTR
            $data = array(
                    'no_ttr'=> $code,
                    'tanggal'=> $tgl_input,
                    'dtr_id'=> $dtr_id,
                    'created'=> $tanggal,
                    'created_by'=> $user_id,
                    'modified'=> $tanggal,
                    'modified_by'=> $user_id
            );
            $this->db->insert('ttr', $data);
            $ttr_id = $this->db->insert_id();
            
            $this->load->model('Model_beli_rongsok');
            $details = $this->Model_beli_rongsok->show_detail_dtr($dtr_id)->result();
            
            foreach ($details as $row){
                $this->db->insert('ttr_detail', array(
                    'ttr_id'=>$ttr_id,
                    'dtr_detail_id'=>$row->id,
                    'rongsok_id'=>$row->rongsok_id,
                    'qty'=>$row->qty,
                    'bruto'=>$row->bruto,
                    'netto'=>$row->netto,
                    'line_remarks'=>$row->line_remarks,
                    'created'=>$tanggal,
                    'created_by'=> $user_id,
                    'modified'=> $tanggal,
                    'modified_by'=> $user_id
                ));
                
                #Update Stok Rongsok
                $get_stok = $this->Model_beli_rongsok->cek_stok($row->nama_item, 'RONGSOK')->row_array(); 
                if($get_stok){
                    $stok_id  = $get_stok['id'];            
                    $this->db->where('id', $stok_id);
                    $this->db->update('t_inventory', array(
                            'stok_bruto'=>($get_stok['stok_bruto']+ $row->bruto), 
                            'stok_netto'=>($get_stok['stok_netto']+ $row->netto), 
                            'modified'=>$tanggal, 
                            'modified_by'=>$user_id));
                }else{
                    $this->db->insert('t_inventory', array(
                            'nama_produk'=>$row->nama_item,
                            'jenis_item'=>'RONGSOK',
                            'stok_bruto'=>$row->bruto, 
                            'stok_netto'=>$row->netto, 
                            'created'=>$tanggal, 
                            'created_by'=>$user_id,
                            'modified'=>$tanggal, 
                            'modified_by'=>$user_id));
                    
                    $stok_id = $this->db->insert_id();
                }
                
                #Save data ke tabel t_inventory_detail
                $this->db->insert('t_inventory_detail', array(
                    't_inventory_id'=>$stok_id,
                    'tanggal'=>$tanggal,
                    'bruto_masuk'=>$row->bruto,
                    'netto_masuk'=>$row->netto,
                    'remarks'=>'Tolling titipan',
                ));
            }
            
            if($this->db->trans_complete()){  
                $return_data['type_message']= "sukses";
                $return_data['message']= "TTR berhasil di-create dengan nomor : ".$code;                 
            }else{
                $return_data['type_message']= "error";
                $return_data['message']= "Terjadi kesalahan saat approve DTR, silahkan coba kembali!";
            }   
        }else{
            $return_data['type_message']= "error";
            $return_data['message']= "Pembuatan TTR gagal, penomoran belum disetup!";
        } 

        
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }
    
    function reject(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        
        $data = array(
                'status'=> 9,
                'rejected'=> $tanggal,
                'rejected_by'=>$user_id,
                'reject_remarks'=>$this->input->post('reject_remarks')
            );
        
        $this->db->where('id', $this->input->post('dtr_id'));
        $this->db->update('dtr', $data);

        redirect('index.php/Tolling/view_dtr/'.$this->input->post('dtr_id'));
    }
    
    function edit_dtr(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/edit_dtr";
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_dtr($id)->row_array(); 
            $data['details'] = $this->Model_tolling_titipan->show_detail_dtr($id)->result();
            
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }
    
    function update_dtr(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        
        $this->db->trans_start();
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('dtr', array(
                    'status'=>0,
                    'remarks'=>$this->input->post('remarks'),
                    'modified'=>$tanggal,
                    'modified_by'=>$user_id
        ));
        
        $details = $this->input->post('myDetails');
        foreach($details as $row){
            $this->db->where('id', $row['id']);
            $this->db->update('dtr_detail', array(
                'bruto'=>str_replace('.','', $row['bruto']),
                'netto'=>str_replace('.','', $row['netto']),
                'line_remarks'=>$row['line_remarks'],
                'no_pallete'=>$row['no_pallete'],
                'modified'=>$tanggal,
                'modified_by'=>$user_id
            ));
        }
        
        if($this->db->trans_complete()){    
            $this->session->set_flashdata('flash_msg', 'DTR dengan nomor : '.$this->input->post('no_dtr').' berhasil diupdate...');                 
        }else{
            $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat updates DTR, silahkan coba kembali!');
        }
        redirect('index.php/Tolling/dtr_list');
    }
    
    function create_ttr(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/create_ttr";
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_dtr($id)->row_array();           
            $data['details'] = $this->Model_tolling_titipan->show_detail_dtr($id)->result(); 
            
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }
    
    function save_ttr(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));

        $this->db->trans_start();
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('TTR', $tgl_input); 
        
        if($code){        
            $data = array(
                        'no_ttr'=> $code,
                        'tanggal'=> $tgl_input,
                        'dtr_id'=> $this->input->post('dtr_id'),
                        'jmlh_afkiran'=>str_replace('.','', $this->input->post('jmlh_afkiran')),
                        'jmlh_pengepakan'=>str_replace('.','', $this->input->post('jmlh_pengepakan')),
                        'jmlh_lain'=>str_replace('.','', $this->input->post('jmlh_lain')),
                        'remarks'=> $this->input->post('remarks'),
                        'created'=> $tanggal,
                        'created_by'=> $user_id,
                        'modified'=> $tanggal,
                        'modified_by'=> $user_id
                    );
            $this->db->insert('ttr', $data);
            $dtr_id = $this->db->insert_id();
            $details = $this->input->post('myDetails');
            foreach ($details as $row){
                if(isset($row['check']) && $row['check']==1){
                    $this->db->insert('ttr_detail', array(
                        'ttr_id'=>$dtr_id,
                        'dtr_detail_id'=>$row['dtr_detail_id'],
                        'rongsok_id'=>$row['rongsok_id'],
                        'qty'=>$row['qty'],
                        'bruto'=>$row['bruto'],
                        'netto'=>$row['netto'],
                        'line_remarks'=>$row['line_remarks']
                    ));
                    
                    $this->db->where('id', $row['dtr_detail_id']);
                    $this->db->update('dtr_detail', array('flag_ttr'=>1));
                }
            }
            
            if($this->db->trans_complete()){    
                $this->session->set_flashdata('flash_msg', 'TTR berhasil di-create dengan nomor : '.$code);                 
            }else{
                $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat create TTR, silahkan coba kembali!');
            }                     
        }else{
            $this->session->set_flashdata('flash_msg', 'Pembuatan TTR gagal, penomoran belum disetup!');
        }
        redirect('index.php/Tolling/dtr_list');  
    }
    
    function ttr_list(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');
        $user_ppn    = $this->session->userdata('user_ppn');
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/ttr_list";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->ttr_list($user_ppn)->result();

        $this->load->view('layout', $data);
    }
    
    function print_ttr(){
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_ttr($id)->row_array();
            $data['details'] = $this->Model_tolling_titipan->show_detail_ttr($id)->result();

            $this->load->view('print_ttr_from_so', $data);
        }else{
            redirect('index.php'); 
        }
    }
    
    // function produksi_ampas(){
    //     $module_name = $this->uri->segment(1);
    //     $group_id    = $this->session->userdata('group_id');        
    //     if($group_id != 1){
    //         $this->load->model('Model_modules');
    //         $roles = $this->Model_modules->get_akses($module_name, $group_id);
    //         $data['hak_akses'] = $roles;
    //     }
    //     $data['group_id']  = $group_id;

    //     $data['content']= "tolling_titipan/produksi_ampas";
    //     $this->load->model('Model_tolling_titipan');
    //     $data['list_data'] = $this->Model_tolling_titipan->produksi_ampas()->result();

    //     $this->load->view('layout', $data);
    // }
    
    // function add_produksi_ampas(){
    //     $module_name = $this->uri->segment(1);
    //     $group_id    = $this->session->userdata('group_id');        
    //     if($group_id != 1){
    //         $this->load->model('Model_modules');
    //         $roles = $this->Model_modules->get_akses($module_name, $group_id);
    //         $data['hak_akses'] = $roles;
    //     }
    //     $data['group_id']  = $group_id;
    //     $data['content']= "tolling_titipan/add_produksi_ampas";
        
    //     $this->load->model('Model_tolling_titipan');
    //     $data['ttr_list'] = $this->Model_tolling_titipan->get_ttr_to_pa()->result();
    //     $data['jenis_barang_list'] = $this->Model_tolling_titipan->jenis_barang_list()->result();
    //     $this->load->view('layout', $data);
    // }
    
    // function save_produksi_ampas(){
    //     $user_id  = $this->session->userdata('user_id');
    //     $tanggal  = date('Y-m-d h:m:s');
    //     $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        
    //     $this->load->model('Model_m_numberings');
    //     $code = $this->Model_m_numberings->getNumbering('PRD', $tgl_input); 
        
    //     if($code){        
    //         $data = array(
    //             'no_produksi'=> $code,
    //             'tanggal'=> $tgl_input,
    //             'jenis_barang'=>$this->input->post('jenis_barang'),
    //             'remarks'=>$this->input->post('remarks'),
    //             'ttr_id'=>$this->input->post('ttr_id'),
    //             'created'=> $tanggal,
    //             'created_by'=> $user_id,
    //             'modified'=> $tanggal,
    //             'modified_by'=> $user_id
    //         );

    //         if($this->db->insert('produksi_ampas', $data)){
    //             redirect('index.php/Tolling/edit_produksi_ampas/'.$this->db->insert_id());  
    //         }else{
    //             $this->session->set_flashdata('flash_msg', 'Data produksi gagal disimpan, silahkan dicoba kembali!');
    //             redirect('index.php/Tolling/produksi_ampas');  
    //         }            
    //     }else{
    //         $this->session->set_flashdata('flash_msg', 'Data produksi gagal disimpan, penomoran belum disetup!');
    //         redirect('index.php/Tolling/produksi_ampas');
    //     }
    // }
    
    // function edit_produksi_ampas(){
    //     $module_name = $this->uri->segment(1);
    //     $id = $this->uri->segment(3);
    //     if($id){
    //         $group_id    = $this->session->userdata('group_id');        
    //         if($group_id != 1){
    //             $this->load->model('Model_modules');
    //             $roles = $this->Model_modules->get_akses($module_name, $group_id);
    //             $data['hak_akses'] = $roles;
    //         }
    //         $data['group_id']  = $group_id;

    //         $data['content']= "tolling_titipan/edit_produksi_ampas";
    //         $this->load->model('Model_tolling_titipan');
    //         $data['header'] = $this->Model_tolling_titipan->show_header_pa($id)->row_array();  
            
    //         $data['ttr_list'] = $this->Model_tolling_titipan->get_ttr_to_pa()->result();
    //         $data['jenis_barang_list'] = $this->Model_tolling_titipan->jenis_barang_list()->result();
    //         $this->load->view('layout', $data);   
    //     }else{
    //         redirect('index.php/Tolling');
    //     }
    // }
    
    // function load_detail_produksi_ampas(){
    //     $id = $this->input->post('id');
        
    //     $tabel = "";
    //     $no    = 1;
    //     $produksi = 0;
    //     $sisa = 0;

    //     $this->load->model('Model_ampas');
    //     $list_ampas = $this->Model_ampas->list_data()->result();
        
    //     $this->load->model('Model_tolling_titipan'); 
    //     $myDetail = $this->Model_tolling_titipan->load_detail_produksi_ampas($id)->result(); 
    //     foreach ($myDetail as $row){
    //         $tabel .= '<tr>';
    //         $tabel .= '<td style="text-align:center">'.$no.'</td>';
    //         $tabel .= '<td>'.$row->nama_item.'</td>';
    //         $tabel .= '<td>'.$row->uom.'</td>';
    //         $tabel .= '<td style="text-align:right">'.number_format($row->hasil_produksi,0,',','.').'</td>';
    //         $tabel .= '<td style="text-align:right">'.number_format($row->sisa,0,',','.').'</td>';
    //         $tabel .= '<td>'.$row->line_remarks.'</td>';            
    //         $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
    //                 . 'red" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
    //                 . '<i class="fa fa-trash"></i> Delete </a></td>';
    //         $tabel .= '</tr>';
    //         $produksi += $row->hasil_produksi;
    //         $sisa += $row->sisa;
            
    //         $no++;
    //     }
            
    //     $tabel .= '<tr>';
    //     $tabel .= '<td style="text-align:center">'.$no.'</td>';
    //     $tabel .= '<td>';
    //     $tabel .= '<select id="ampas_id" name="ampas_id" class="form-control select2me myline" ';
    //         $tabel .= 'data-placeholder="Pilih..." style="margin-bottom:5px" onclick="get_uom(this.value);">';
    //         $tabel .= '<option value=""></option>';
    //         foreach ($list_ampas as $value){
    //             $tabel .= "<option value='".$value->id."'>".$value->nama_item."</option>";
    //         }
    //     $tabel .= '</select>';
    //     $tabel .= '</td>';
    //     $tabel .= '<td><input type="text" id="uom" name="uom" class="form-control myline" readonly="readonly"></td>';
        
    //     $tabel .= '<td><input type="text" id="hasil_produksi" name="hasil_produksi" class="form-control myline" '
    //             . 'onkeydown="return myCurrency(event);" maxlength="10" value="0" onkeyup="getComa(this.value, this.id);"></td>';
    //     $tabel .= '<td><input type="text" id="sisa" name="sisa" class="form-control myline" '
    //             . 'onkeydown="return myCurrency(event);" maxlength="10" value="0" onkeyup="getComa(this.value, this.id);"></td>';
        
    //     $tabel .= '<td><input type="text" id="line_remarks" name="line_remarks" class="form-control myline" onkeyup="this.value = this.value.toUpperCase()"></td>';        
    //     $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
    //             . 'yellow-gold" onclick="saveDetail();" style="margin-top:5px" id="btnSaveDetail"> '
    //             . '<i class="fa fa-plus"></i> Tambah </a></td>';
    //     $tabel .= '</tr>';
        
    //     $tabel .= '<tr>';
    //     $tabel .= '<td colspan="3" style="text-align:right"><strong>Total </strong></td>';
    //     $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($produksi,0,',','.').'</strong></td>';
    //     $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($sisa,0,',','.').'</strong></td>';
    //     $tabel .= '<td></td>';
    //     $tabel .= '<td></td>';
    //     $tabel .= '</tr>';
       
        
    //     header('Content-Type: application/json');
    //     echo json_encode($tabel); 
    // }
    
    // function get_uom_ampas(){
    //     $id = $this->input->post('id');
    //     $this->load->model('Model_ampas');
    //     $ampas= $this->Model_ampas->show_data($id)->row_array();
        
    //     header('Content-Type: application/json');
    //     echo json_encode($ampas); 
    // }
    
    // function delete_detail_produksi_ampas(){
    //     $id = $this->input->post('id');
    //     $return_data = array();
    //     $this->db->where('id', $id);
    //     if($this->db->delete('produksi_ampas_detail')){
    //         $return_data['message_type']= "sukses";
    //     }else{
    //         $return_data['message_type']= "error";
    //         $return_data['message']= "Gagal menghapus item ampas! Silahkan coba kembali";
    //     }           
    //     header('Content-Type: application/json');
    //     echo json_encode($return_data);
    // }
    
    // function save_detail_produksi_ampas(){
    //     $user_id  = $this->session->userdata('user_id');
    //     $tanggal  = date('Y-m-d h:m:s');
        
    //     $return_data = array();
    //     $this->db->trans_start(); 
        
    //     $hasil_produksi = str_replace('.', '', $this->input->post('hasil_produksi'));
    //     $sisa = str_replace('.', '', $this->input->post('sisa'));
        
    //     $this->db->insert('produksi_ampas_detail', array(
    //         'produksi_ampas_id'=>$this->input->post('id'),
    //         'ampas_id'=>$this->input->post('ampas_id'),
    //         'hasil_produksi'=>$hasil_produksi,
    //         'sisa'=>$sisa,
    //         'line_remarks'=>$this->input->post('line_remarks')
    //     ));
        
    //     #Update Stok Ampas
    //     $this->load->model('Model_beli_rongsok');
    //     $get_stok = $this->Model_beli_rongsok->cek_stok($this->input->post('jenis_item'), 'AMPAS')->row_array(); 
    //     if($get_stok){
    //         $stok_id  = $get_stok['id'];            
    //         $this->db->where('id', $stok_id);
    //         $this->db->update('t_inventory', array(
    //                 'stok_bruto'=>($get_stok['stok_bruto']+ $hasil_produksi), 
    //                 'stok_netto'=>($get_stok['stok_netto']+ $hasil_produksi), 
    //                 'modified'=>$tanggal, 
    //                 'modified_by'=>$user_id));
    //     }else{
    //         $this->db->insert('t_inventory', array(
    //                 'nama_produk'=>$this->input->post('jenis_item'),
    //                 'jenis_item'=>'AMPAS',
    //                 'stok_bruto'=>$hasil_produksi, 
    //                 'stok_netto'=>$hasil_produksi, 
    //                 'created'=>$tanggal, 
    //                 'created_by'=>$user_id,
    //                 'modified'=>$tanggal, 
    //                 'modified_by'=>$user_id));

    //         $stok_id = $this->db->insert_id();
    //     }
        
    //     #Save data ke tabel t_inventory_detail
    //     $this->db->insert('t_inventory_detail', array(
    //         't_inventory_id'=>$stok_id,
    //         'tanggal'=>$tanggal,
    //         'bruto_masuk'=>$hasil_produksi,
    //         'netto_masuk'=>$hasil_produksi,
    //         'remarks'=>'Produksi ampas tolling titipan',
    //     ));
        
    //     if($this->db->trans_complete()){  
    //         $return_data['message_type']= "sukses";               
    //     }else{
    //         $return_data['message_type']= "error";
    //         $return_data['message']= "Gagal menambahkan item ampas! Silahkan coba kembali";
    //     }  

    //     header('Content-Type: application/json');
    //     echo json_encode($return_data); 
    // }
    
    // function update_produksi_ampas(){
    //     $user_id  = $this->session->userdata('user_id');
    //     $tanggal  = date('Y-m-d h:m:s');        
    //     $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        
    //     $data = array(
    //             'tanggal'=> $tgl_input,
    //             'jenis_barang'=>$this->input->post('jenis_barang'),
    //             'remarks'=>$this->input->post('remarks'),
    //             'ttr_id'=>$this->input->post('ttr_id'),
    //             'modified'=> $tanggal,
    //             'modified_by'=> $user_id
    //         );
        
    //     $this->db->where('id', $this->input->post('id'));
    //     $this->db->update('produksi_ampas', $data);
        
    //     $this->session->set_flashdata('flash_msg', 'Data produksi ampas berhasil disimpan');
    //     redirect('index.php/Tolling/produksi_ampas');
    // }
    
    function surat_jalan(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        $user_ppn = $this->session->userdata('user_ppn');
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/surat_jalan";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->surat_jalan($user_ppn)->result();

        $this->load->view('layout', $data);
    }

    function surat_jalan_keluar(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        $user_ppn = $this->session->userdata('user_ppn');
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/surat_jalan_keluar";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->surat_jalan_keluar($user_ppn)->result();

        $this->load->view('layout', $data);
    }
    
    function add_surat_jalan(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;
        $data['content']= "tolling_titipan/add_surat_jalan";
        
        $this->load->model('Model_tolling_titipan');
        $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
        $this->load->model('Model_sales_order');
        $data['type_kendaraan_list'] = $this->Model_sales_order->type_kendaraan_list()->result();
        $this->load->view('layout', $data);
    }

    function add_surat_jalan_keluar(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;
        $data['content']= "tolling_titipan/add_surat_jalan_keluar";
        
        $this->load->model('Model_tolling_titipan');
        $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
        $this->load->model('Model_sales_order');
        $data['type_kendaraan_list'] = $this->Model_sales_order->type_kendaraan_list()->result();
        $this->load->view('layout', $data);
    }
    
    function get_type_kendaraan(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $type_kendaraan = $this->Model_tolling_titipan->get_type_kendaraan($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($type_kendaraan); 
    }
    
    function get_alamat(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $customer = $this->Model_tolling_titipan->get_alamat($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($customer); 
    }
    
    function get_so_list(){ 
        $user_ppn = $this->session->userdata('user_ppn');
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->get_so_list($id, $user_ppn)->result();
        $arr_so[] = "Silahkan pilih....";
        foreach ($data as $row) {
            $arr_so[$row->id] = $row->no_sales_order;
        } 
        print form_dropdown('sales_order_id', $arr_so);
    }
    
    function save_surat_jalan(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('SJ', $tgl_input); 
        
        if($code){        
            $data = array(
                'no_surat_jalan'=> $code,
                'sales_order_id'=>$this->input->post('sales_order_id'),
                'tanggal'=> $tgl_input,
                'jenis_barang'=>$this->input->post('jenis_barang'),
                'm_customer_id'=>$this->input->post('m_customer_id'),
                'm_type_kendaraan_id'=>$this->input->post('m_type_kendaraan_id'),
                'no_kendaraan'=>$this->input->post('no_kendaraan'),
                'supir'=>$this->input->post('supir'),
                'remarks'=>$this->input->post('remarks'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            );

            if($this->db->insert('t_surat_jalan', $data)){
                redirect('index.php/Tolling/edit_surat_jalan/'.$this->db->insert_id());  
            }else{
                $this->session->set_flashdata('flash_msg', 'Data surat jalan gagal disimpan, silahkan dicoba kembali!');
                redirect('index.php/Tolling/surat_jalan');  
            }            
        }else{
            $this->session->set_flashdata('flash_msg', 'Data surat jalan gagal disimpan, penomoran belum disetup!');
            redirect('index.php/Tolling/surat_jalan');
        }
    }

    function save_surat_jalan_keluar(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('SJ-T', $tgl_input); 
        
        if($code){        
            $data = array(
                'no_surat_jalan'=> $code,
                'spb_id'=>$this->input->post('no_spb'),
                'po_id'=>$this->input->post('po_id'),
                'tanggal'=> $tgl_input,
                'jenis_barang'=>$this->input->post('jenis_barang'),
                'm_customer_id'=>$this->input->post('m_customer_id'),
                'm_type_kendaraan_id'=>$this->input->post('m_type_kendaraan_id'),
                'no_kendaraan'=>$this->input->post('no_kendaraan'),
                'supir'=>$this->input->post('supir'),
                'remarks'=>$this->input->post('remarks'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            );

            if($this->db->insert('t_surat_jalan', $data)){
                redirect('index.php/Tolling/edit_surat_jalan_keluar/'.$this->db->insert_id());  
            }else{
                $this->session->set_flashdata('flash_msg', 'Data surat jalan gagal disimpan, silahkan dicoba kembali!');
                redirect('index.php/Tolling/surat_jalan');  
            }            
        }else{
            $this->session->set_flashdata('flash_msg', 'Data surat jalan gagal disimpan, penomoran belum disetup!');
            redirect('index.php/Tolling/surat_jalan');
        }
    }
    
    function edit_surat_jalan(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/edit_surat_jalan";
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_sj($id)->row_array();
            $data['type_kendaraan_list'] = $this->Model_tolling_titipan->type_kendaraan_list()->result();
            $data['jenis_barang'] = $this->Model_tolling_titipan->jenis_barang_in_so($data['header']['sales_order_id'])->result();
            if($data['header']['jenis_barang'] == 'FG'){
                $data['list_barang_spb'] = $this->Model_tolling_titipan->list_item_sj_fg($data['header']['sales_order_id'])->result();
            }else{
                $data['list_barang_spb'] = $this->Model_tolling_titipan->list_item_sj_wip($data['header']['sales_order_id'])->result();
            }
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling/surat_jalan');
        }
    }

    function edit_surat_jalan_keluar(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/edit_surat_jalan_keluar";
            $this->load->model('Model_sales_order');
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_sj_only($id)->row_array();  
            $data['customer_list'] = $this->Model_sales_order->customer_list()->result();
            $data['type_kendaraan_list'] = $this->Model_sales_order->type_kendaraan_list()->result();

            $jenis = $data['header']['jenis_barang'];
            $spbid = $data['header']['spb_id'];
            if($jenis == 'FG'){
                $data['list_produksi'] = $this->Model_tolling_titipan->list_item_sjk_fg($spbid)->result();
            }else if($jenis == 'WIP'){
                $data['list_produksi'] = $this->Model_tolling_titipan->list_item_sjk_wip($spbid)->result();
            }else{
                $data['list_produksi'] = $this->Model_tolling_titipan->list_item_sjk_rsk($spbid)->result();
            }
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling/surat_jalan_keluar');
        }
    }

    function get_data_fg(){
        $id = $this->input->post('id');
        $jb = $this->input->post('jenis_barang');
        $this->load->model('Model_tolling_titipan');
        if($jb == 'FG'){
            $uom= $this->Model_tolling_titipan->get_data_fg($id)->row_array();
        }else{
            $uom= $this->Model_tolling_titipan->list_item_sj_wip_detail($id)->row_array();
        }
        
        header('Content-Type: application/json');
        echo json_encode($uom); 
    }

    function get_data_sj(){
        $id = $this->input->post('id');
        $jb = $this->input->post('jenis_barang');
        $this->load->model('Model_tolling_titipan');
        if($jb=='FG'){
        $sj_detail= $this->Model_tolling_titipan->list_item_sjk_fg_detail($id)->row_array();
        }else if($jb=='WIP'){
        $sj_detail= $this->Model_tolling_titipan->list_item_sjk_wip_detail($id)->row_array();
        }else{
        $sj_detail= $this->Model_tolling_titipan->list_item_sjk_rsk_detail($id)->row_array();
        }
        
        header('Content-Type: application/json');
        echo json_encode($sj_detail); 
    }
    
    function update_surat_jalan(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');        
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $jenis = $this->input->post('jenis_barang');
        $soid = $this->input->post('so_id');

        #Insert Surat Jalan
        $details = $this->input->post('details');
        foreach ($details as $v) {
            if($v['id_barang']!='' || $v['id_barang']!= 0){
                if($jenis=='FG'){// BARANG FINISH GOOD
                    $this->db->insert('t_surat_jalan_detail', array(
                        't_sj_id'=>$this->input->post('id'),
                        'gudang_id'=>$v['id_barang'],
                        'jenis_barang_id'=>$v['jenis_barang_id'],
                        'jenis_barang_alias'=>$v['barang_alias_id'],
                        'no_packing'=>$v['no_packing'],
                        'qty'=>'1',
                        'bruto'=>$v['bruto'],
                        'netto'=>$v['netto'],
                        'nomor_bobbin'=>$v['bobbin'],
                        'line_remarks'=>$v['line_remarks'],
                        'created_by'=>$user_id,
                        'created_at'=>$tanggal
                    ));
                }else{
                    $this->db->insert('t_surat_jalan_detail', array(
                        't_sj_id'=>$this->input->post('id'),
                        'gudang_id'=>$v['id_barang'],
                        'jenis_barang_id'=>$v['jenis_barang_id'],
                        'no_packing'=>0,
                        'qty'=>$v['qty'],
                        'bruto'=>0,
                        'netto'=>$v['netto'],
                        'nomor_bobbin'=>0,
                        'line_remarks'=>$v['line_remarks'],
                        'created_by'=>$user_id,
                        'created_at'=>$tanggal
                    ));
                }
            }
        }

        $data = array(
                'tanggal'=> $tgl_input,
                'm_type_kendaraan_id'=>$this->input->post('m_type_kendaraan_id'),
                'no_kendaraan'=>$this->input->post('no_kendaraan'),
                'supir'=>$this->input->post('supir'),
                'remarks'=>$this->input->post('remarks'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            );
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('t_surat_jalan', $data);
        
        $this->session->set_flashdata('flash_msg', 'Data surat jalan berhasil disimpan');
        redirect('index.php/Tolling/surat_jalan');
    }

    function update_surat_jalan_keluar(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');        
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $jenis = $this->input->post('jenis_barang');
        $soid = $this->input->post('so_id');

        #Insert Surat Jalan
        $details = $this->input->post('details');
        foreach ($details as $v) {
            if($v['id_barang']!=''){
                if($jenis=='FG'){// BARANG FINISH GOOD
                    $this->db->insert('t_surat_jalan_detail', array(
                        't_sj_id'=>$this->input->post('id'),
                        'gudang_id'=>$v['id_barang'],
                        'jenis_barang_id'=>$v['jenis_barang_id'],
                        'no_packing'=>$v['no_packing'],
                        'qty'=>'1',
                        'bruto'=>$v['bruto'],
                        'netto'=>$v['netto'],
                        'nomor_bobbin'=>$v['bobbin'],
                        'line_remarks'=>$v['line_remarks'],
                        'created_by'=>$user_id,
                        'created_at'=>$tanggal
                    ));
                }else if($jenis=='WIP'){//BARANG WIP
                    $this->db->insert('t_surat_jalan_detail', array(
                        't_sj_id'=>$this->input->post('id'),
                        'gudang_id'=>$v['id_barang'],
                        'jenis_barang_id'=>$v['jenis_barang_id'],
                        'no_packing'=>0,
                        'qty'=>$v['qty'],
                        'bruto'=>0,
                        'netto'=>$v['netto'],
                        'nomor_bobbin'=>0,
                        'line_remarks'=>$v['line_remarks'],
                        'created_by'=>$user_id,
                        'created_at'=>$tanggal
                    ));
                }else if($jenis=='RONGSOK'){
                    $this->db->insert('t_surat_jalan_detail', array(
                        't_sj_id'=>$this->input->post('id'),
                        'gudang_id'=>$v['id_barang'],
                        'jenis_barang_id'=>$v['jenis_barang_id'],
                        'no_packing'=>$v['no_palette'],
                        'qty'=>$v['qty'],
                        'bruto'=>$v['bruto'],
                        'netto'=>$v['netto'],
                        'nomor_bobbin'=>0,
                        'line_remarks'=>$v['line_remarks'],
                        'created_by'=>$user_id,
                        'created_at'=>$tanggal
                    ));
                }
            }
        }

        $data = array(
                'tanggal'=> $tgl_input,
                'm_type_kendaraan_id'=>$this->input->post('m_type_kendaraan_id'),
                'no_kendaraan'=>$this->input->post('no_kendaraan'),
                'supir'=>$this->input->post('supir'),
                'remarks'=>$this->input->post('remarks'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            );
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('t_surat_jalan', $data);

        
        $this->session->set_flashdata('flash_msg', 'Data surat jalan berhasil disimpan');
        redirect('index.php/Tolling/surat_jalan_keluar');
    }

    function view_surat_jalan(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/view_sj";
            $this->load->model('Model_sales_order');
            $data['header'] = $this->Model_sales_order->show_header_sj($id)->row_array();  
            $data['customer_list'] = $this->Model_sales_order->customer_list()->result();
            $data['type_kendaraan_list'] = $this->Model_sales_order->type_kendaraan_list()->result();
            $data['list_sj'] = $this->Model_sales_order->load_view_sjd($id)->result();

            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/SalesOrder/surat_jalan');
        }
    }

    function view_surat_jalan_keluar(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        $user_ppn = $this->session->userdata('user_ppn');
        if($id){
            $group_id    = $this->session->userdata('group_id');
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/view_sj_keluar";
            $this->load->model('Model_sales_order');
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_sj_only($id)->row_array();
            $custid = $data['header']['m_customer_id'];
            $jenis = $data['header']['jenis_barang'];

            $data['list_po'] = $this->Model_tolling_titipan->get_po_tolling($custid,$user_ppn)->result();
            if($jenis == 'FG'){
                $data['list_sj'] = $this->Model_sales_order->load_view_sjd($id)->result();
            }else if($jenis == 'WIP'){
                $data['list_sj'] = $this->Model_sales_order->load_detail_surat_jalan_wip($id)->result();
            }else{
                $data['list_sj'] = $this->Model_sales_order->load_detail_surat_jalan_rsk($id)->result();
            }

            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling/surat_jalan_keluar');
        }
    }

    function approve_surat_jalan(){
        $sjid = $this->input->post('id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d');
        $so_id = $this->input->post('so_id');
        $custid = $this->input->post('id_customer');
        $jenis = $this->input->post('jenis_barang');

        $this->db->trans_start();
        
        #set flag taken
        $loop = $this->db->query("select *from t_surat_jalan_detail where t_sj_id = ".$sjid)->result();
        if ($jenis == 'FG') {
            foreach ($loop as $row) {
                $this->db->where('id', $row->gudang_id);
                $this->db->update('t_gudang_fg', array('flag_taken' => 1));
            }
        } else if ($jenis == 'WIP') {
            foreach ($loop as $row) {
                $this->db->where('id', $row->gudang_id);
                $this->db->update('t_gudang_wip', array('flag_taken' => 1));
            }
        }

        $this->load->model('Model_sales_order');
        #cek jika surat jalan sudah di kirim semua atau belum
        if($jenis == 'FG'){
            $list_produksi = $this->Model_sales_order->list_item_sj_fg($so_id)->result();
        }else if($jenis == 'WIP'){
            $list_produksi = $this->Model_sales_order->list_item_sj_wip($so_id)->result();
        }

        $this->db->where('id',$so_id);
        $this->db->update('sales_order', array(
            'flag_invoice'=>0
        ));

        if(empty($list_produksi) && $this->input->post('status_spb') == 1){
            $this->db->where('id',$so_id);
            $this->db->update('sales_order', array(
                'flag_sj'=>1
            ));
        }

        if($jenis == 'FG'){
            #insert bobbin_peminjaman
            $this->load->model('Model_m_numberings');
            $code = $this->Model_m_numberings->getNumbering('BB-BR', $tgl_input);

            $this->db->insert('m_bobbin_peminjaman', array(
                'no_surat_peminjaman' => $code,
                'id_surat_jalan' => $sjid,
                'id_customer' => $custid,
                'status' => 0,
                'created_by' => $user_id,
                'created_at' => $tanggal
            ));
            $insert_id = $this->db->insert_id();

            $query = $this->db->query('select *from t_surat_jalan_detail where t_sj_id = '.$sjid)->result();
            foreach ($query as $row) {
                $this->db->where('nomor_bobbin', $row->nomor_bobbin);
                $this->db->update('m_bobbin', array(
                    'borrowed_by' => $custid,
                    'status' => 2
                ));

                $this->db->insert('m_bobbin_peminjaman_detail', array(
                    'id_peminjaman' => $insert_id,
                    'nomor_bobbin' => $row->nomor_bobbin
                ));
            }
        }

        $data = array(
                'status' => 1,
                'approved_at'=> $tanggal,
                'approved_by'=> $user_id
            );
        
        $this->db->where('id', $sjid);
        $this->db->update('t_surat_jalan', $data);

        if($this->db->trans_complete()){    
            $this->session->set_flashdata('flash_msg', 'Surat jalan sudah di-approve. Detail Surat jalan sudah disimpan');            
        }else{
            $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat pembuatan Surat Jalan, silahkan coba kembali!');
        }             
        
       redirect('index.php/Tolling/surat_jalan');
    }

    function approve_surat_jalan_keluar(){
        $sjid = $this->input->post('id');
        $spbid = $this->input->post('spb_id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d');
        $custid = $this->input->post('id_customer');
        $jenis = $this->input->post('jenis_barang');

        $this->db->trans_start();
        
        #set flag taken
        $loop = $this->db->query("select *from t_surat_jalan_detail where t_sj_id = ".$sjid)->result();
        if ($jenis == 'FG') {
            foreach ($loop as $row) {
                $this->db->where('id', $row->gudang_id);
                $this->db->update('t_gudang_fg', array('flag_taken' => 1));
            }
        } else if ($jenis == 'WIP') {
            foreach ($loop as $row) {
                $this->db->where('id', $row->gudang_id);
                $this->db->update('t_gudang_wip', array('flag_taken' => 1));
            }
        } else if ($jenis == 'RONGSOK'){
            foreach ($loop as $row) {
                $this->db->where('id', $row->gudang_id);
                $this->db->update('dtr_detail', array('flag_sj' => 1));
            }
        }

        $this->load->model('Model_tolling_titipan');
        #cek jika surat jalan sudah di kirim semua atau belum
            if($jenis == 'FG'){
                if($this->input->post('status_spb') == 1){
                    $this->db->where('id',$spbid);
                    $this->db->update('t_spb_fg', array(
                        'flag_tolling'=>2
                    ));
                }
            }else if($jenis == 'WIP'){
                if($this->input->post('status_spb') == 1){
                    $this->db->where('id',$spbid);
                    $this->db->update('t_spb_wip', array(
                        'flag_tolling'=>2
                    ));
                }
            }else{
                if($this->input->post('status_spb') == 1){
                    $this->db->where('id',$spbid);
                    $this->db->update('spb', array(
                        'flag_tolling'=>2
                    ));
                }
            }


        if($jenis=='FG'){
            #insert bobbin_peminjaman
            $this->load->model('Model_m_numberings');
            $code = $this->Model_m_numberings->getNumbering('BB-BR', $tgl_input);

            $this->db->insert('m_bobbin_peminjaman', array(
                'no_surat_peminjaman' => $code,
                'id_surat_jalan' => $sjid,
                'id_customer' => $custid,
                'status' => 0,
                'created_by' => $user_id,
                'created_at' => $tanggal
            ));
            $insert_id = $this->db->insert_id();

            $query = $this->db->query('select *from t_surat_jalan_detail where t_sj_id = '.$sjid)->result();
            foreach ($query as $row) {
                $this->db->where('nomor_bobbin', $row->nomor_bobbin);
                $this->db->update('m_bobbin', array(
                    'borrowed_by' => $custid,
                    'status' => 2
                ));

                $this->db->insert('m_bobbin_peminjaman_detail', array(
                    'id_peminjaman' => $insert_id,
                    'nomor_bobbin' => $row->nomor_bobbin
                ));
            }
        }
        
        $data = array(
                'status' => 1,
                'approved_at'=> $tanggal,
                'approved_by'=> $user_id
            );
        
        $this->db->where('id', $sjid);
        $this->db->update('t_surat_jalan', $data);

        if($this->db->trans_complete()){    
            $this->session->set_flashdata('flash_msg', 'Surat jalan sudah di-approve. Detail Surat jalan sudah disimpan');            
        }else{
            $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat pembuatan Surat Jalan, silahkan coba kembali!');
        }             
        
       redirect('index.php/Tolling/surat_jalan_keluar');
    }

    function reject_surat_jalan(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $sjid = $this->input->post('sj_id');
        
        #Update status t_surat_jalan
        $data = array(
                'status'=> 9,
                'rejected_at'=> $tanggal,
                'rejected_by'=>$user_id,
                'reject_remarks'=>$this->input->post('reject_remarks')
            );
        
        $this->db->where('id', $sjid);
        $this->db->update('t_surat_jalan', $data);
        
        $this->session->set_flashdata('flash_msg', 'Surat jalan berhasil direject');
        redirect('index.php/Tolling/surat_jalan');
    }

    function reject_surat_jalan_keluar(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $sjid = $this->input->post('sj_id');
        
        #Update status t_surat_jalan
        $data = array(
                'status'=> 9,
                'rejected_at'=> $tanggal,
                'rejected_by'=>$user_id,
                'reject_remarks'=>$this->input->post('reject_remarks')
            );
        
        $this->db->where('id', $sjid);
        $this->db->update('t_surat_jalan', $data);
        
        $this->session->set_flashdata('flash_msg', 'Surat jalan berhasil direject');
        redirect('index.php/Tolling/surat_jalan_keluar');
    }

    function simpan_surat_jalan_keluar(){
        $sjid = $this->input->post('id');
        $data = array(
                'po_id'=>$this->input->post('po_id')
            );
        
        $this->db->where('id', $sjid);
        $this->db->update('t_surat_jalan', $data);

        $this->session->set_flashdata('flash_msg', 'Surat jalan berhasil disimpan');
        redirect('index.php/Tolling/surat_jalan_keluar');
    }
    
    function print_surat_jalan(){
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_tolling_titipan');
            $data['header']  = $this->Model_tolling_titipan->show_header_sj($id)->row_array();
            $data['details'] = $this->Model_tolling_titipan->load_detail_surat_jalan($id)->result();

            $this->load->view('tolling_titipan/print_sj', $data);
        }else{
            redirect('index.php'); 
        }
    }

    function get_jenis_barang(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $jenis_barang = $this->Model_tolling_titipan->get_jenis_barang($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($jenis_barang); 
    }

    function tolling_fg(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/tolling_fg";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->tolling_fg()->result();

        $this->load->view('layout', $data);
    }

    function view_tolling(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/view_tolling";

            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_tolling_fg($id)->row_array();
            $data['details'] = $this->Model_tolling_titipan->show_detail_tolling_fg($id)->result();
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/GudangFG/spb_list');
        }
    }

    function add_tolling_fg(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');
        $data['user_ppn'] = $this->session->userdata('user_ppn');       
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;
        $data['content']= "tolling_titipan/add_tolling_fg";
        
        $this->load->model('Model_tolling_titipan');
        $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
        $data['marketing_list'] = $this->Model_tolling_titipan->marketing_list()->result();
        $this->load->view('layout', $data);
    }

    function get_detail_so(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->get_detail_so($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data); 
    }

    function save_tolling_fg(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $user_ppn  = $this->session->userdata('user_ppn');
        
        $this->load->model('Model_m_numberings');
        $code= $this->Model_m_numberings->getNumbering('PO-T', $tgl_input);
        
        if($code){
            $data = array(
                'no_po'=> $code,
                'tanggal'=> $tgl_input,
                'ppn'=> $user_ppn,
                'customer_id'=>$this->input->post('customer_id'),
                'term_of_payment'=>$this->input->post('top'),
                'jenis_po'=>$this->input->post('jenis_barang'),
                'remarks'=>$this->input->post('remarks'),
                'created'=> $tanggal,
                'created_by'=> $user_id
            );

            if($this->db->insert('po', $data)){
                redirect('index.php/Tolling/edit_tolling_fg/'.$this->db->insert_id());  
            }else{
                $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, silahkan dicoba kembali!');
                redirect('index.php/Tolling');  
            }            
        }else{
            $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, penomoran belum disetup!');
            redirect('index.php/Tolling');
        }
    }

    function edit_tolling_fg(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "tolling_titipan/edit_tolling_fg";
            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_tolling($id)->row_array();
            $jenis = $data['header']['jenis_po'];
            $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
            $data['list_barang'] = $this->Model_tolling_titipan->jenis_barang($jenis)->result();
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }

    function close_po(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        
        $data = array(
                'status'=> 1,
                'modified'=> $tanggal,
                'modified_by'=>$user_id,
                'remarks'=>$this->input->post('reject_remarks')
            );
        
        $this->db->where('id', $this->input->post('header_id'));
        $this->db->update('po', $data);
        
        $this->session->set_flashdata('flash_msg', 'PO Tolling Berhasil di Close');
        redirect('index.php/Tolling/po_list');
    }

    function load_detail_tolling(){
        $id = $this->input->post('id');
        
        $tabel = "";
        $total = 0;
        $qty = 0;
        $no    = 1;
        $this->load->model('Model_tolling_titipan');
        $list_barang = $this->Model_tolling_titipan->get_barang_fg()->result();
        
        $myDetail = $this->Model_tolling_titipan->load_tolling_detail($id)->result(); 
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';
            $tabel .= '<td>'.$row->jenis_barang.'</td>';
            $tabel .= '<td>'.$row->uom.'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->qty,0,',','.').'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->amount,0,',','.').'</td>';
            $tabel .= '<td style="text-align:right">'.number_format($row->total_amount,0,',','.').'</td>';
            $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
                    . 'red" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a></td>';
            $tabel .= '</tr>';
            $qty += $row->qty;
            $total += $row->total_amount;
            $no++;
        }

        $tabel .= '<tr>';
        $tabel .= '<td colspan="3" style="text-align:right"><strong>Total Jumlah </strong></td>';
        $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($qty,0,',','.').'</strong></td>';
        $tabel .= '<td style="text-align:right"><strong>Total (Rp) </strong></td>';
        $tabel .= '<td style="text-align:right; background-color:green; color:white"><strong>'.number_format($total,0,',','.').'</strong></td>';
        $tabel .= '</tr>';

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    function save_detail_tolling(){
        $return_data = array();
        
        if($this->db->insert('po_detail', array(
            'po_id'=>$this->input->post('id'),
            'jenis_barang_id'=>$this->input->post('jenis_barang'),
            'amount'=>str_replace('.', '', $this->input->post('harga')),
            'qty'=>str_replace('.', '', $this->input->post('qty')),
            'total_amount'=>str_replace('.', '', $this->input->post('total'))
        ))){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item rongsok! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }
    
    function delete_detail_tolling(){
        $id = $this->input->post('id');
        $return_data = array();
        $this->db->where('id', $id);
        if($this->db->delete('po_detail')){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menghapus item tolling detail! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function get_uom_tolling(){
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $uom= $this->Model_tolling_titipan->get_uom_tolling($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($uom); 
    }

    function update_tolling_fg(){
        $id = $this->input->post('id');
        $user_id  = $this->session->userdata('user_id');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tanggal  = date('Y-m-d');
        
        $this->db->trans_start();

        $this->db->where('id', $id);
        $this->db->update('po', array(
            'customer_id' => $this->input->post('customer_id'),
            'tanggal' => $tgl_input
        ));
        
        if($this->db->trans_complete()){    
            $this->session->set_flashdata('flash_msg', 'PO Tolling berhasil di buat...');                 
        }else{
            $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat membuat SPB FG, silahkan coba kembali!');
        }
        redirect('index.php/Tolling/po_list');
    }

    function cek_balance(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/cek_balance";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->cek_balance_list()->result();

        $this->load->view('layout', $data);
    }

    function view_balance(){
        $id = $this->uri->segment(3);
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/view_balance";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->view_balance($id)->result();

        $this->load->view('layout', $data);
    }

    function po_list(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');     
        $user_ppn = $this->session->userdata('user_ppn');   
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/po_list";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->po_list($user_ppn)->result();

        $this->load->view('layout', $data);
    }

    function dtt_list(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/dtt_list";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->dtt_list()->result();

        $this->load->view('layout', $data);
    }

    function create_dtt(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');
        $data['user_ppn'] = $this->session->userdata('user_ppn');       
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;
        $data['content']= "tolling_titipan/add_dtt";
        
        $this->load->model('Model_tolling_titipan');
        $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
        $this->load->model('Model_gudang_fg');
        $data['packing'] = $this->Model_gudang_fg->packing_fg_list()->result();
        $this->load->view('layout', $data);
    }

    function save_dtt(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tgl_po = date('Y-m-d', strtotime($this->input->post('tanggal_po')));
        $user_ppn  = $this->session->userdata('user_ppn');
        
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('DTT', $tgl_input); 
        
        if($code){
            $this->db->trans_start();    
            $data = array(
                'no_dtt'=> $code,
                'tanggal'=> $tgl_input,
                'customer_id'=>$this->input->post('customer_id'),
                'jenis_barang'=>$this->input->post('jenis_barang'),
                'jenis_packing'=>$this->input->post('packing'),
                'remarks'=>$this->input->post('remarks'),
                'created'=> $tanggal,
                'created_by'=> $user_id,
            );
            $this->db->insert('dtt', $data);
            $id = $this->db->insert_id();

            if($this->db->trans_complete()){
                redirect('index.php/Tolling/edit_dtt/'.$id);  
            }else{
                $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, silahkan dicoba kembali!');
                redirect('index.php/Tolling');  
            }            
        }else{
            $this->session->set_flashdata('flash_msg', 'Sales order gagal disimpan, penomoran belum disetup!');
            redirect('index.php/Tolling');
        }
    }

    function edit_dtt(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $this->load->model('Model_tolling_titipan');
            $data['header'] = $this->Model_tolling_titipan->show_header_dtt($id)->row_array();
            if($data['header']['jenis_packing']=='KARDUS'){
                $data['content']= "tolling_titipan/edit_dtt_kardus";
                $this->load->model('Model_gudang_fg');
                $data['packing'] =  $this->Model_gudang_fg->packing_list_by_name('KARDUS')->result();
            }else{
                $data['content']= "tolling_titipan/edit_dtt";
            }
            $jenis = $data['header']['jenis_barang'];
            $data['customer_list'] = $this->Model_tolling_titipan->customer_list()->result();
            $data['list_barang'] = $this->Model_tolling_titipan->jenis_barang($jenis)->result();
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/Tolling');
        }
    }

    function delete_detail_rambut(){
        $id = $this->input->post('id');
        $return_data = array();

        $this->db->where('id', $id);
        if($this->db->delete('dtt_detail')){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menghapus item barang! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function save_detail_rambut(){
        $return_data = array();
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $user_id  = $this->session->userdata('user_id');

        $this->db->trans_start();

        $this->db->insert('dtt_detail', array(
            'dtt_id'=>$this->input->post('id'),
            'jenis_barang_id' => $this->input->post('jb'),
            'bruto' => $this->input->post('bruto'),
            'berat_bobbin' => $this->input->post('berat'),
            'netto' => $this->input->post('netto'),
            'no_bobbin' => $this->input->post('no_bobbin'),
            'no_packing' => $this->input->post('no_packing'),
            'line_remarks' => $this->input->post('keterangan'),
            'created' => $tanggal,
            'created_by' => $user_id,
            'tanggal_masuk'=> $tgl_input
        ));
        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item barang! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    function save_dtt_detail(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $jenis = $this->input->post('jenis_barang');
        $dtt_id = $this->input->post('id');

        $this->db->trans_start();

        $details = $this->input->post('myDetails');
        foreach ($details as $row){
            if($jenis=='FG'){
                if($row['jb_id']!=0 && $row['no_bobbin']!=''){
                        $this->db->insert('dtt_detail', array(
                            'dtt_id'=>$dtt_id,
                            'jenis_barang_id'=>$row['jb_id'],
                            'bruto'=>$row['bruto'],
                            'berat_bobbin'=>$row['berat_bobbin'],
                            'netto'=>$row['netto'],
                            'no_bobbin'=>$row['no_bobbin'],
                            'no_packing'=>$row['no_packing'],
                            'line_remarks'=>$row['line_remarks'],
                            'created'=>$tanggal,
                            'created_by'=>$user_id,
                            'tanggal_masuk'=>$tgl_input
                        ));
                $updatebobbin = array('status'=>1);
                $this->db->where('nomor_bobbin', $row['no_bobbin']);
                $this->db->update('m_bobbin', $updatebobbin);
                }
            }else if($jenis=='WIP'){
                if($row['jb_id']!=0 && $row['netto']!= (0 || '')){
                        $this->db->insert('dtt_detail', array(
                            'dtt_id'=>$dtt_id,
                            'jenis_barang_id'=>$row['jb_id'],
                            'qty'=>$row['qty'],
                            'netto'=>$row['netto'],
                            'line_remarks'=>$row['line_remarks'],
                            'created'=>$tanggal,
                            'created_by'=>$user_id,
                            'tanggal_masuk'=>$tgl_input
                        ));
                }
            }
        }

        if($this->db->trans_complete()){    
            $this->session->set_flashdata('flash_msg', 'DTT berhasil dibuat');                 
        }else{
            $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat create DTT, silahkan coba kembali!');
        }
        redirect('index.php/Tolling/dtt_list');
    }

    function load_detail_rambut(){
        $id = $this->input->post('id');
        
        $tabel = "";
        $no    = 1;
        $this->load->model('Model_tolling_titipan');
        $myDetail = $this->Model_tolling_titipan->load_detail_dtt($id)->result(); 
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';
            $tabel .= '<td>'.$row->jenis_barang.'</td>';
            $tabel .= '<td>'.$row->uom.'</td>';
            $tabel .= '<td><a href="javascript:;" onclick="timbang(this)" class="btn btn-xs btn-circle blue disabled"><i class="fa fa-dashboard"></i> Timbang</a></td>';
            $tabel .= '<td>'.$row->bruto.'</td>';
            $tabel .= '<td>'.$row->berat_bobbin.'</td>';
            $tabel .= '<td>'.$row->netto.'</td>';
            $tabel .= '<td>'.$row->no_packing.'</td>';
            $tabel .= '<td>'.$row->line_remarks.'</td>';
            $tabel .= '<td style="text-align:center"><a href="javascript:;" class="btn btn-xs btn-circle '
                    . 'red" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a>'
                    . '<a href="javascript:;" class="btn btn-circle btn-xs blue-ebonyclay"'
                    . 'onclick="printBarcode('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Print Barcode </a></td>';
            $tabel .= '</tr>';            
            $no++;
        }

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    function spb_list(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/spb_list";
        $this->load->model('Model_tolling_titipan');
        $data['list_data'] = $this->Model_tolling_titipan->spb_list()->result();

        $this->load->view('layout', $data);
    }

    function add_spb(){
        $module_name = $this->uri->segment(1);
        $group_id    = $this->session->userdata('group_id');        
        if($group_id != 1){
            $this->load->model('Model_modules');
            $roles = $this->Model_modules->get_akses($module_name, $group_id);
            $data['hak_akses'] = $roles;
        }
        $data['group_id']  = $group_id;

        $data['content']= "tolling_titipan/add_spb";
        $this->load->model('Model_tolling_titipan');
        
        $this->load->view('layout', $data);
    }

    function save_spb(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $jenis = $this->input->post('jenis_barang');

        $this->load->model('Model_m_numberings');
        if($jenis == 'FG'){
            $code = $this->Model_m_numberings->getNumbering('SPB-FGT', $tgl_input); 
            if($code){        
                $data = array(
                    'no_spb'=> $code,
                    'tanggal'=> $tgl_input,
                    'flag_tolling'=> 1,
                    'keterangan'=>$this->input->post('remarks'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                );

                if($this->db->insert('t_spb_fg', $data)){
                    redirect('index.php/GudangFG/edit_spb/'.$this->db->insert_id());  
                }else{
                    $this->session->set_flashdata('flash_msg', 'Data SPB FG gagal disimpan, silahkan dicoba kembali!');
                    redirect('index.php/Tolling/add_spb');  
                }            
            }else{
                $this->session->set_flashdata('flash_msg', 'Data SPB FG gagal disimpan, penomoran belum disetup!');
                redirect('index.php/Tolling/spb_list');
            }
        }else if($jenis == 'WIP'){
            $code = $this->Model_m_numberings->getNumbering('SPB-WIPT', $tgl_input); 
            if($code){        
                $data = array(
                    'no_spb_wip'=> $code,
                    'tanggal'=> $tgl_input,
                    'flag_produksi'=> 4,
                    'flag_tolling'=> 1,
                    'keterangan'=>$this->input->post('remarks'),
                    'created'=> $tanggal,
                    'created_by'=> $user_id
                );

                if($this->db->insert('t_spb_wip', $data)){
                    redirect('index.php/GudangWIP/edit_spb/'.$this->db->insert_id());  
                }else{
                    $this->session->set_flashdata('flash_msg', 'Data SPB WIP gagal disimpan, silahkan dicoba kembali!');
                    redirect('index.php/Tolling/add_spb');  
                }            
            }else{
                $this->session->set_flashdata('flash_msg', 'Data SPB FG gagal disimpan, penomoran belum disetup!');
                redirect('index.php/Tolling/spb_list');
            }
        }else if($jenis == 'RONGSOK'){
            $code = $this->Model_m_numberings->getNumbering('SPB-RSKT', $tgl_input); 
            if($code){        
                $data = array(
                    'no_spb'=> $code,
                    'tanggal'=> $tgl_input,
                    'jenis_barang'=>2,
                    'flag_tolling'=> 1,
                    'jumlah'=> $this->input->post('jumlah_rsk'),
                    'remarks'=>$this->input->post('remarks'),
                    'created'=> $tanggal,
                    'created_by'=> $user_id
                );

                if($this->db->insert('spb', $data)){
                    redirect('index.php/Ingot/add_spb/'.$this->db->insert_id());  
                }else{
                    $this->session->set_flashdata('flash_msg', 'Data SPB Rongsok gagal disimpan, silahkan dicoba kembali!');
                    redirect('index.php/Tolling/add_spb');  
                }            
            }else{
                $this->session->set_flashdata('flash_msg', 'Data SPB Rongsok gagal disimpan, penomoran belum disetup!');
                redirect('index.php/Tolling/spb_list');
            }
        }
    }

    function edit_spb(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "gudang_fg/edit_spb";
            $this->load->model('Model_gudang_fg');
            $data['header'] = $this->Model_gudang_fg->show_header_spb($id)->row_array();
            $data['details'] =   $this->Model_gudang_fg->show_detail_spb($id)->result();
    
            $this->load->view('layout', $data);
        }else{
            redirect('index.php/GudangFG/spb_list');
        }
    }

    function view_spb(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['group_id']  = $group_id;

            $data['content']= "gudang_fg/view_spb";

            $this->load->model('Model_gudang_fg');
            $data['list_barang'] = $this->Model_gudang_fg->barang_fg_stock_list()->result();
            $data['myData'] = $this->Model_gudang_fg->show_header_spb($id)->row_array();
            $data['myDetail'] = $this->Model_gudang_fg->show_detail_spb($id)->result();
            $data['myDetailSaved'] = $this->Model_gudang_fg->show_detail_spb_saved($id)->result();
            $data['detailSPB'] = $this->Model_gudang_fg->show_detail_spb_fulfilment($id)->result();
            $this->load->view('layout', $data);   
        }else{
            redirect('index.php/GudangFG/spb_list');
        }
    }

    function filter_spb(){
        $module_name = $this->uri->segment(1);
        $id = $this->uri->segment(3);
        if($id){
            $group_id    = $this->session->userdata('group_id');        
            if($group_id != 1){
                $this->load->model('Model_modules');
                $roles = $this->Model_modules->get_akses($module_name, $group_id);
                $data['hak_akses'] = $roles;
            }
            $data['jenis']     = $id;
            $data['group_id']  = $group_id;
            $data['judul']     = "Finance";
            $data['content']   = "tolling_titipan/filter_spb";

            $this->load->model('Model_tolling_titipan');
            if($id == 'rongsok'){
                $data['list_data'] = $this->Model_tolling_titipan->list_data_filter_rsk()->result();
            }else if($id == 'wip'){
                $data['list_data'] = $this->Model_tolling_titipan->list_data_filter_wip()->result();
            }else if($id == 'fg'){
                $data['list_data'] = $this->Model_tolling_titipan->list_data_filter_fg()->result();
            }

            $this->load->view('layout', $data);
        }else{
            redirect('index.php/Tolling');
        }
    }

    function get_no_spb(){ 
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        if($id == 'RONGSOK'){
            $data = $this->Model_tolling_titipan->get_spb_list_rsk($id)->result();
        }else if($id == 'WIP'){
            $data = $this->Model_tolling_titipan->get_spb_list_wip($id)->result();
        }else if($id == 'FG'){
            $data = $this->Model_tolling_titipan->get_spb_list_fg($id)->result();
        }
        $arr_so[] = "Silahkan pilih....";
        foreach ($data as $row) {
            $arr_so[$row->id] = $row->no_spb;
        } 
        print form_dropdown('no_spb', $arr_so);
    }

    function get_po_tolling(){ 
        $user_ppn = $this->session->userdata('user_ppn');
        $id = $this->input->post('id');
        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->get_po_tolling($id, $user_ppn)->result();
        $arr_so[] = "Silahkan pilih....";
        foreach ($data as $row) {
            $arr_so[$row->id] = $row->no_po;
        } 
        print form_dropdown('no_po', $arr_so);
    }

    function create_voucher(){
        $id = $this->input->post('id');
        $this->load->helper('terbilang_helper');
        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->voucher_po($id)->row_array();
        $terbilang = $data['nilai_po'];
        $sisa = $data['nilai_po'] - $data['nilai_dp'];
        $data['nilai_po'] = number_format($data['nilai_po'],0,',','.');
        $data['nilai_dp'] = number_format($data['nilai_dp'],0,',','.');
        $data['sisa']     = number_format($sisa,0,',','.');

        $data['terbilang'] = ucwords(number_to_words($terbilang));
        
        header('Content-Type: application/json');
        echo json_encode($data);  
    }

    function save_voucher(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d h:m:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $nilai_po  = str_replace('.', '', $this->input->post('nilai_po'));
        $nilai_dp  = str_replace('.', '', $this->input->post('nilai_dp'));
        $amount  = str_replace('.', '', $this->input->post('amount'));
        $id = $this->input->post('id');
        
        $this->db->trans_start();
        $this->load->model('Model_m_numberings');
        $code = $this->Model_m_numberings->getNumbering('VTL', $tgl_input);
        if($nilai_po-($nilai_dp+$amount)>0){
            $jenis_voucher = 'DP';
        }else{
            $jenis_voucher = 'Pelunasan';
            $this->db->where('id', $id);
            $this->db->update('po', array('flag_pelunasan'=>1,'status'=>4));
        } 

        if($code){ 
            $this->db->insert('voucher', array(
                'no_voucher'=>$code,
                'tanggal'=>$tgl_input,
                'jenis_voucher'=>$jenis_voucher,
                'po_id'=>$this->input->post('id'),
                'customer_id'=>$this->input->post('customer_id'),
                'jenis_barang'=>$this->input->post('jenis_barang'),
                'amount'=>str_replace('.', '', $this->input->post('amount')),
                'keterangan'=>$this->input->post('keterangan'),
                'created'=> $tanggal,
                'created_by'=> $user_id,
                'modified'=> $tanggal,
                'modified_by'=> $user_id
            ));
            
            if($this->db->trans_complete()){    
                $this->session->set_flashdata('flash_msg', 'Voucher finish good berhasil di-create dengan nomor : '.$code);                 
            }else{
                $this->session->set_flashdata('flash_msg', 'Terjadi kesalahan saat create voucher finish good, silahkan coba kembali!');
            }
            redirect('index.php/Tolling/po_list');  
        }else{
            $this->session->set_flashdata('flash_msg', 'Pembuatan voucher finish good gagal, penomoran belum disetup!');
            redirect('index.php/Tolling/po_list');
        }
    }

    function print_barcode_dtt(){
        $fg_id = $_GET['fg'];
        $bruto = $_GET['b'];
        $berat_bobbin = $_GET['bp'];
        $netto = $_GET['n'];
        $no_packing = $_GET['np'];
        if($netto){

        $this->load->model('Model_sales_order');
        $data = $this->Model_sales_order->get_jb($fg_id)->row_array();

        $current = '';
        $data_printer = $this->db->query("select * from m_print_barcode_line")->result_array();
        $data_printer[17]['string1'] = 'BARCODE 488,335,"39",41,0,180,2,6,"'.$data['kode'].'"';
        $data_printer[18]['string1'] = 'TEXT 386,289,"ROMAN.TTF",180,1,8,"'.$data['kode'].'"';
        $data_printer[22]['string1'] = 'BARCODE 612,101,"39",41,0,180,2,6,"'.$no_packing.'"';
        $data_printer[23]['string1'] = 'TEXT 426,55,"ROMAN.TTF",180,1,8,"'.$no_packing.'"';
        $data_printer[24]['string1'] = 'TEXT 499,260,"4",180,1,1,"'.$no_packing.'"';
        $data_printer[25]['string1'] = 'TEXT 495,226,"ROMAN.TTF",180,1,14,"'.$bruto.'"';
        $data_printer[26]['string1'] = 'TEXT 495,188,"ROMAN.TTF",180,1,14,"'.$berat_bobbin.'"';
        $data_printer[27]['string1'] = 'TEXT 495,147,"0",180,14,14,"'.$netto.'"';
        $data_printer[31]['string1'] = 'TEXT 496,373,"2",180,1,1,"'.$data['jenis_barang'].'"';
        $data_printer[32]['string1'] = 'TEXT 497,407,"4",180,1,1,"'.$data['kode'].'"';
        $jumlah = count($data_printer);
        for($i=0;$i<$jumlah;$i++){
        $current .= $data_printer[$i]['string1']."\n";
        }
        echo "<form method='post' id=\"coba\" action=\"http://localhost/print/print.php\">";
        echo "<input type='hidden' id='nospb' name='nospb' value='".$current."'>";
        echo "</form>";
        echo '<script type="text/javascript">document.getElementById(\'coba\').submit();</script>';
        }else{
            'GAGAL';
        }
    }

    function get_bobbin(){
        $id = $this->input->post('id');
        $this->load->model('Model_beli_fg');
        $barang= $this->Model_beli_fg->show_data_bobbin($id)->row_array();
        // $this->load->model('Model_tolling_titipan');
        // $check = $this->Model_tolling_titipan->check_urut()->row_array();
        // $no_urut = $check['no_urut'];
        // $no_urut = $no_urut + 1;
        // switch (strlen($no_urut)) {
        //     case 1 : $urutan = "000".$no_urut;
        //         break;
        //     case 2 : $urutan = "00".$no_urut;
        //         break;
        //     case 3 : $urutan = "0".$no_urut;
        //         break;
            
        //     default:
        //         $urutan = $no_urut;
        //         break;
        // }

        $no_bobbin = $barang['nomor_bobbin'];
        $kode_bobbin = substr($no_bobbin, 0,1);
        $urut_bobbin = substr($no_bobbin, 1,4);
        $ukuran = $this->input->post('ukuran');
        $barang['no_packing'] = date("ymd").$kode_bobbin.$ukuran.$urut_bobbin;
        header('Content-Type: application/json');
        echo json_encode($barang); 
    }

    function print_barcode_kardus(){
        $id = $_GET['id'];
        if($id){

        $this->load->model('Model_tolling_titipan');
        $data = $this->Model_tolling_titipan->get_detail_dtt($id)->row_array();
        $berat = $data['bruto'] - $data['netto'];

        $current = '';
        $data_printer = $this->db->query("select * from m_print_barcode_line")->result_array();
        $data_printer[17]['string1'] = 'BARCODE 488,335,"39",41,0,180,2,6,"'.$data['kode'].'"';
        $data_printer[18]['string1'] = 'TEXT 386,289,"ROMAN.TTF",180,1,8,"'.$data['kode'].'"';
        $data_printer[22]['string1'] = 'BARCODE 612,101,"39",41,0,180,2,6,"'.$data['no_packing'].'"';
        $data_printer[23]['string1'] = 'TEXT 426,55,"ROMAN.TTF",180,1,8,"'.$data['no_packing'].'"';
        $data_printer[24]['string1'] = 'TEXT 499,260,"4",180,1,1,"'.$data['no_packing'].'"';
        $data_printer[25]['string1'] = 'TEXT 495,226,"ROMAN.TTF",180,1,14,"'.$data['bruto'].'"';
        $data_printer[26]['string1'] = 'TEXT 495,188,"ROMAN.TTF",180,1,14,"'.$berat.'"';
        $data_printer[27]['string1'] = 'TEXT 495,147,"0",180,14,14,"'.$data['netto'].'"';
        $data_printer[31]['string1'] = 'TEXT 496,373,"2",180,1,1,"'.$data['jenis_barang'].'"';
        $data_printer[32]['string1'] = 'TEXT 497,407,"4",180,1,1,"'.$data['kode'].'"';
        $jumlah = count($data_printer);
        for($i=0;$i<$jumlah;$i++){
        $current .= $data_printer[$i]['string1']."\n";
        }
        echo "<form method='post' id=\"coba\" action=\"http://localhost/print/print.php\">";
        echo "<input type='hidden' id='nospb' name='nospb' value='".$current."'>";
        echo "</form>";
        echo '<script type="text/javascript">document.getElementById(\'coba\').submit();</script>';
        }else{
            'GAGAL';
        }
    }
}